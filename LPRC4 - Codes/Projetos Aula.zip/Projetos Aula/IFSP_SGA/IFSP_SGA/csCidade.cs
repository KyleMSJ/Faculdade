﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace IFSP_SGA
{
    public class csCidade
    {
        private Int32 idCity;
        private string nomeCity;
        private string bairroCity;
        private string LogradouroCity;
        private string CEPCity;
        private string numeroCity; // número da residência 
        private string complementoCity;
        private string descricaoCity;

        private conexaoMySql conexao = new conexaoMySql();
        // Gets e Sets

        public void setCityId(Int32 valor)
        {
            idCity = valor;
        }
        public Int32 getCityId()
        {
            return idCity;
        }

        public void setCityNome(string valor)
        {
            nomeCity = valor;
        }
        public string getCityNome()
        {
            return nomeCity;
        }

        public void setCityBairro(string valor)
        {
            bairroCity = valor;
        }
        public string getCityBairro()
        {
            return bairroCity;
        }

        public void setLogradouroCity(string valor)
        {
            LogradouroCity = valor;
        }
        public string getLogradouroCity()
        {
            return LogradouroCity;
        }

        public void setCEPCity(string valor)
        {
            CEPCity = valor;
        }
        public string getCEPCity()
        {
            return CEPCity;
        }

        public void setNumeroCity(string valor)
        {
            numeroCity = valor;
        }
        public string getNumeroCity()
        {
            return numeroCity;
        }

        public void setComplementoCity(string valor)
        {
            complementoCity = valor;
        }
        public string getComplementoCity()
        {
            return complementoCity;
        }

        public void setDescricaoCity(string valor)
        {
            descricaoCity = valor;
        }
        public string getDescricaoCity()
        {
            return descricaoCity;
        }
        public void inserir()
        {
            string sql = "INSERT INTO cidade(cidadenome, cidadebairro, cidadedescricao, cidadeCEP, cidadenumero";
            sql += ", cidadecomplemento, cidadelogradouro) VALUES (";
            sql += "'" + nomeCity + "', ";
            sql += "'" + bairroCity + "', ";
            sql += "'" + descricaoCity + "', ";
            sql += "'" + CEPCity + "', ";
            sql += "'" + numeroCity + "', ";
            sql += "'" + complementoCity + "', ";
            sql += "'" + LogradouroCity + "'";
            sql += ")";
            conexao.executarSql(sql);
        }

        public void delete()
        {
            string sql = "Delete from cidade WHERE cidadeid = " + idCity.ToString() + ";";
            conexao.executarSql(sql);
        }

        public void update()
        {
            string sql = "UPDATE cidade SET ";
            sql += "cidadenome = '" + nomeCity + "', ";
            sql += "cidadebairro = '" + bairroCity + "', ";
            sql += "cidadedescricao = '" + descricaoCity + "', ";
            sql += "cidadeCEP = '" + CEPCity + "', ";
            sql += "cidadenumero = '" + numeroCity + "', ";
            sql += "cidadecomplemento = '" + complementoCity + "', ";
            sql += "cidadelogradouro = '" + LogradouroCity + "' ";
            sql += "WHERE cidadeid = " + idCity + ";";
            conexao.executarSql(sql);
        }
        public DataTable select()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable tabela = new DataTable();
            string sql = "SELECT cidadeid, cidadenome from cidade;";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(tabela);
            return tabela;
        }

        public void selectCidade()
        {
                MySqlDataAdapter adapter = new MySqlDataAdapter();
                DataSet dataSet = new DataSet();
                string sql = "SELECT cidadenome, cidadebairro, cidadedescricao, cidadeCEP, cidadenumero, ";
                sql += "cidadecomplemento, cidadelogradouro FROM cidade WHERE cidadeid = " + idCity.ToString() + ";";
                adapter = conexao.executaRetornaDados(sql);
                adapter.Fill(dataSet);

                nomeCity = dataSet.Tables[0].Rows[0][0].ToString(); 
                bairroCity = dataSet.Tables[0].Rows[0][1].ToString();
                descricaoCity = dataSet.Tables[0].Rows[0][2].ToString();
                CEPCity = dataSet.Tables[0].Rows[0][3].ToString();
                numeroCity = dataSet.Tables[0].Rows[0][4].ToString();
                complementoCity = dataSet.Tables[0].Rows[0][5].ToString();
                LogradouroCity = dataSet.Tables[0].Rows[0][6].ToString();
        }
        
    }
}
