﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IFSP_SGA
{
    public partial class frmEstado : Form
    {
        csEstado estado = new csEstado();
        private void habilitaControles(bool status)
        {
            txtNome.Enabled = status;
            txtSigla.Enabled = status;
        }
        private void gerenciaBotoesBarra(bool status)
        {
            btnNovo.Enabled = status;
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;
            btnSair.Enabled = status;
            btnSalvar.Enabled = !status;
            btnCancelar.Enabled = !status;
        }

        private void limparControles()
        {
            estado.setEstadoId(0);          
            txtNome.Text = "";
            txtSigla.Text = "";
        }

        private void formataGrid()
        {
            grdDados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdDados.Columns[0].HeaderText = "Código";
            grdDados.Columns[1].HeaderText = "Nome do Estado";

            grdDados.Columns[0].Width = 0;
            grdDados.Columns[1].Width = 200;
        }

        private void preencheGrid()
        {
            grdDados.DataSource = estado.select(); 
            formataGrid();
        }

        private void preencheDadosControles()
        {
            estado.selectEstado();

            txtNome.Text = estado.getNomeEstado();
            txtSigla.Text = estado.getSiglaEstado();
        }


        private bool validaDados()
        {
            if (txtNome.Text.Trim().Length <= 4)
            {
                MessageBox.Show("Nome do Estado é obrigatório, informe!", "Aviso!!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNome.Focus(); // Cursor na caixa de texto do nome
                return false;
            }
            return true;
        }

        private void salvarEstado ()
        {
            estado.setNomeEstado(txtNome.Text);
            estado.setSiglaEstado(txtNome.Text);

            if (estado.getEstadoId() == 0)
            {
                estado.inserir();
            }
            else
            {
                estado.update();
            }
        }
        private void excluiEstado()
        {
            estado.delete();
        }
        public frmEstado()
        {
            InitializeComponent();
        }

        private void frmEstado_Load(object sender, EventArgs e)
        {
            habilitaControles(false);
            gerenciaBotoesBarra(true);
            preencheGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            limparControles();
            gerenciaBotoesBarra(false);
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            gerenciaBotoesBarra(false);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (validaDados() == true)
            {
                salvarEstado();
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
                preencheGrid();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja cancelar a manutenção do Estado?", "Aviso!!!",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult retorno = MessageBox.Show("Deseja excluir o estado selecionado?",
                "Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (retorno == DialogResult.Yes)
            {
                excluiEstado();
                limparControles();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void grdDados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            estado.setEstadoId(Convert.ToInt32(grdDados.Rows[grdDados.CurrentRow.Index].Cells[0].Value.ToString()));
            preencheDadosControles();

        }
    }
}
