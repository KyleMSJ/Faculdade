﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient; // Cria a tabela e recebe as informações
using System.Data; // possui o DataTable

namespace IFSP_SGA
{
    public class csDisciplina 
    {
        private Int32 idDisc;
        private string nomeDisc;
        private string siglaDisc;
        private Int16 cargaHorariaDisc;
        private Int16 semestreDisc; // Índice do combo-box
        private bool teoriaDisc;
        private bool praticaDisc;
        private bool obrigatoriaDisc;
        private string descricaoDisc;
        private string preRequisitoDisc;

        private conexaoMySql conexao = new conexaoMySql();

        public void setDiscId(Int32 valor) // atribuindo uma informação para o atributo - tratamentos podem ser inclusos aqui
        {
            idDisc = valor;
        }

        public Int32 getDiscId () // lê o valor - também aqui (conversões por exemplo)
        {
            return idDisc;
        }

        public void setDiscNome(string valor)
        {
            nomeDisc = valor;
        }

        public string getDiscNome()
        {
            return nomeDisc;
        }
        public void setDiscSigla(string valor)
        {
            siglaDisc = valor;
        }

        public string getDiscSigla()
        {
            return siglaDisc;
        }
        public void setDiscCargaHoraria(Int16 valor)
        {
            cargaHorariaDisc = valor;
        }

        public Int16 getDiscCargaHoraria()
        {
            return cargaHorariaDisc;
        }
        public void setDiscSemestre(Int16 valor)
        {
            semestreDisc = valor;
        }

        public Int16 getDiscSemestre()
        {
            return semestreDisc;
        }
        public void setDiscTeorica(bool valor)
        {
            teoriaDisc = valor;
        }

        public bool getDiscTeorica()
        {
            return teoriaDisc;
        }
        public void setDiscPratica(bool valor)
        {
            praticaDisc = valor;
        }

        public bool getDiscPratica()
        {
            return praticaDisc;
        }
        public void setDiscObrigatoria(bool valor)
        {
            obrigatoriaDisc = valor;
        }

        public bool getDiscObrigatoria()
        {
            return obrigatoriaDisc;
        }
        public void setDiscDescricao(string valor)
        {
            descricaoDisc = valor;
        }

        public string getDiscDescricao()
        {
            return descricaoDisc;
        }
        public void setDiscPreRequisitos(string valor)
        {
            preRequisitoDisc = valor;
        }

        public string getDiscPreRequisitos()
        {
            return preRequisitoDisc;
        }

        public void inserir() // um dos *métodos* que são usados
        {
            string sql = "INSERT INTO disciplina(disciplinasigla, disciplinanome, disciplinadescricao,";
            sql += "disciplinacargahoraria, disciplinateorica, disciplinapratica, disciplinaobrigatoria,";
            sql += "disciplinarequisitos, disciplinasemestre) VALUES (";
            sql += "'" + siglaDisc + "', ";
            sql += "'" + nomeDisc + "', ";
            sql += "'" + descricaoDisc + "', ";
            sql += cargaHorariaDisc + ", ";
            sql += teoriaDisc + ", ";
            sql += praticaDisc + ", ";
            sql += obrigatoriaDisc + ", ";
            sql += "'" + preRequisitoDisc + "', ";
            sql += semestreDisc;
            sql += ")";
            conexao.executarSql(sql);
        }
        
        public void update()
        {
            string sql = "UPDATE disciplina SET ";
            sql += "disciplinasigla = '" + siglaDisc + "', ";
            sql += "disciplinanome = '" + nomeDisc + "', ";
            sql += "disciplinadescricao = '" + descricaoDisc + "', ";
            sql += "disciplinacargahoraria = " + cargaHorariaDisc + ",";
            sql += "disciplinateorica = " + teoriaDisc + ",";
            sql += "disciplinapratica = " + praticaDisc + ",";
            sql += "disciplinaobrigatoria = " + obrigatoriaDisc + ",";
            sql += "disciplinarequisitos = '" + preRequisitoDisc + "',";
            sql += "disciplinasemestre = " + semestreDisc;
            sql += " WHERE disciplinaid = " + idDisc + ";";
            conexao.executarSql(sql);
        }

        public void delete()
        {
            string sql = "Delete from disciplina WHERE disciplinaid = " + idDisc.ToString() + ";";
            conexao.executarSql(sql);
        }
        
        public DataTable select()   
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable tabela = new DataTable();
            // instrução sql que retorna ID, sigla e nome da disciplina 
            string sql = "Select disciplinaid, disciplinasigla, disciplinanome from disciplina";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(tabela);
            return tabela;
        }

        public void selectDisciplina()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataSet = new DataSet();
            string sql = "SELECT disciplinasigla, disciplinanome, disciplinadescricao, disciplinacargahoraria,";
            sql += "disciplinateorica, disciplinapratica, disciplinaobrigatoria, disciplinarequisitos,";
            sql += "disciplinasemestre FROM disciplina WHERE disciplinaid = " + idDisc.ToString() + ";";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataSet);

            siglaDisc = dataSet.Tables[0].Rows[0][0].ToString(); // Linha 0, coluna 0
            nomeDisc = dataSet.Tables[0].Rows[0][1].ToString(); // Linha 0, coluna 1 
            descricaoDisc = dataSet.Tables[0].Rows[0][2].ToString();
            cargaHorariaDisc = Convert.ToInt16(dataSet.Tables[0].Rows[0][3].ToString());
            teoriaDisc = Convert.ToBoolean(dataSet.Tables[0].Rows[0][4].ToString());
            praticaDisc = Convert.ToBoolean(dataSet.Tables[0].Rows[0][5].ToString());
            obrigatoriaDisc = Convert.ToBoolean(dataSet.Tables[0].Rows[0][6].ToString());
            preRequisitoDisc = dataSet.Tables[0].Rows[0][7].ToString();
            semestreDisc = Convert.ToInt16(dataSet.Tables[0].Rows[0][8].ToString());
        }

    }
}
