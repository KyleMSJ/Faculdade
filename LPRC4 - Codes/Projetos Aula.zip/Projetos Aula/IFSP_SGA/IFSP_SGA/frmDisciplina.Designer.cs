﻿
namespace IFSP_SGA
{
    partial class frmDisciplina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDisciplina));
            this.chkTeorica = new System.Windows.Forms.CheckBox();
            this.chkPratica = new System.Windows.Forms.CheckBox();
            this.chkObrigatoria = new System.Windows.Forms.CheckBox();
            this.grdDados = new System.Windows.Forms.DataGridView();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.barDisciplina = new System.Windows.Forms.ToolStrip();
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.lblSigla = new System.Windows.Forms.Label();
            this.txtSigla = new System.Windows.Forms.TextBox();
            this.lblCargaHoraria = new System.Windows.Forms.Label();
            this.txtCargaHoraria = new System.Windows.Forms.TextBox();
            this.lblSemestre = new System.Windows.Forms.Label();
            this.cboSemestre = new System.Windows.Forms.ComboBox();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.lblPreRequisitos = new System.Windows.Forms.Label();
            this.txtPreRequisitos = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.grdDados)).BeginInit();
            this.barDisciplina.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkTeorica
            // 
            this.chkTeorica.AutoSize = true;
            this.chkTeorica.Location = new System.Drawing.Point(470, 189);
            this.chkTeorica.Margin = new System.Windows.Forms.Padding(4);
            this.chkTeorica.Name = "chkTeorica";
            this.chkTeorica.Size = new System.Drawing.Size(80, 24);
            this.chkTeorica.TabIndex = 0;
            this.chkTeorica.Text = "Teórica";
            this.chkTeorica.UseVisualStyleBackColor = true;
            // 
            // chkPratica
            // 
            this.chkPratica.AutoSize = true;
            this.chkPratica.Location = new System.Drawing.Point(385, 189);
            this.chkPratica.Margin = new System.Windows.Forms.Padding(4);
            this.chkPratica.Name = "chkPratica";
            this.chkPratica.Size = new System.Drawing.Size(77, 24);
            this.chkPratica.TabIndex = 1;
            this.chkPratica.Text = "Prática";
            this.chkPratica.UseVisualStyleBackColor = true;
            // 
            // chkObrigatoria
            // 
            this.chkObrigatoria.AutoSize = true;
            this.chkObrigatoria.Location = new System.Drawing.Point(558, 189);
            this.chkObrigatoria.Margin = new System.Windows.Forms.Padding(4);
            this.chkObrigatoria.Name = "chkObrigatoria";
            this.chkObrigatoria.Size = new System.Drawing.Size(106, 24);
            this.chkObrigatoria.TabIndex = 2;
            this.chkObrigatoria.Text = "Obrigatória";
            this.chkObrigatoria.UseVisualStyleBackColor = true;
            // 
            // grdDados
            // 
            this.grdDados.AllowUserToAddRows = false;
            this.grdDados.AllowUserToDeleteRows = false;
            this.grdDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDados.Location = new System.Drawing.Point(13, 58);
            this.grdDados.Margin = new System.Windows.Forms.Padding(4);
            this.grdDados.Name = "grdDados";
            this.grdDados.ReadOnly = true;
            this.grdDados.Size = new System.Drawing.Size(360, 485);
            this.grdDados.TabIndex = 3;
            this.grdDados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdDados_CellClick);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(381, 68);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 4;
            this.lblNome.Text = "Nome";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(385, 91);
            this.txtNome.MaxLength = 60;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(613, 26);
            this.txtNome.TabIndex = 5;
            // 
            // barDisciplina
            // 
            this.barDisciplina.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.barDisciplina.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.barDisciplina.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNovo,
            this.btnAlterar,
            this.btnExcluir,
            this.btnSalvar,
            this.btnCancelar,
            this.btnSair});
            this.barDisciplina.Location = new System.Drawing.Point(0, 0);
            this.barDisciplina.Name = "barDisciplina";
            this.barDisciplina.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.barDisciplina.Size = new System.Drawing.Size(1010, 55);
            this.barDisciplina.TabIndex = 6;
            this.barDisciplina.Text = "toolStrip1";
            // 
            // btnNovo
            // 
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(52, 52);
            this.btnNovo.Text = "toolStripButton1";
            this.btnNovo.ToolTipText = "Cadastra uma nova Disciplina";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Image")));
            this.btnAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(52, 52);
            this.btnAlterar.Text = "toolStripButton2";
            this.btnAlterar.ToolTipText = "Edita a Disciplina selecionada";
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(52, 52);
            this.btnExcluir.Text = "toolStripButton3";
            this.btnExcluir.ToolTipText = "Exclui a Disciplina selecionada";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(52, 52);
            this.btnSalvar.Text = "toolStripButton4";
            this.btnSalvar.ToolTipText = "Salva os dados da Disciplina";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(52, 52);
            this.btnCancelar.Text = "toolStripButton5";
            this.btnCancelar.ToolTipText = "Cancela a inclusão/edição";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(52, 52);
            this.btnSair.Text = "toolStripButton6";
            this.btnSair.ToolTipText = "Finaliza a manutenção de disciplina";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblSigla
            // 
            this.lblSigla.AutoSize = true;
            this.lblSigla.Location = new System.Drawing.Point(381, 133);
            this.lblSigla.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSigla.Name = "lblSigla";
            this.lblSigla.Size = new System.Drawing.Size(44, 20);
            this.lblSigla.TabIndex = 4;
            this.lblSigla.Text = "Sigla";
            // 
            // txtSigla
            // 
            this.txtSigla.Location = new System.Drawing.Point(385, 156);
            this.txtSigla.MaxLength = 10;
            this.txtSigla.Name = "txtSigla";
            this.txtSigla.Size = new System.Drawing.Size(106, 26);
            this.txtSigla.TabIndex = 5;
            // 
            // lblCargaHoraria
            // 
            this.lblCargaHoraria.AutoSize = true;
            this.lblCargaHoraria.Location = new System.Drawing.Point(511, 133);
            this.lblCargaHoraria.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCargaHoraria.Name = "lblCargaHoraria";
            this.lblCargaHoraria.Size = new System.Drawing.Size(108, 20);
            this.lblCargaHoraria.TabIndex = 4;
            this.lblCargaHoraria.Text = "Carga Horária";
            // 
            // txtCargaHoraria
            // 
            this.txtCargaHoraria.Location = new System.Drawing.Point(515, 156);
            this.txtCargaHoraria.Name = "txtCargaHoraria";
            this.txtCargaHoraria.Size = new System.Drawing.Size(106, 26);
            this.txtCargaHoraria.TabIndex = 5;
            // 
            // lblSemestre
            // 
            this.lblSemestre.AutoSize = true;
            this.lblSemestre.Location = new System.Drawing.Point(641, 133);
            this.lblSemestre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSemestre.Name = "lblSemestre";
            this.lblSemestre.Size = new System.Drawing.Size(78, 20);
            this.lblSemestre.TabIndex = 4;
            this.lblSemestre.Text = "Semestre";
            // 
            // cboSemestre
            // 
            this.cboSemestre.FormattingEnabled = true;
            this.cboSemestre.Items.AddRange(new object[] {
            "1º Semestre",
            "2º Semestre",
            "3º Semestre",
            "4º Semestre",
            "5º Semestre",
            "6º Semestre",
            "7º Semestre",
            "8º Semestre",
            "9º Semestre",
            "10º Semestre"});
            this.cboSemestre.Location = new System.Drawing.Point(645, 154);
            this.cboSemestre.Name = "cboSemestre";
            this.cboSemestre.Size = new System.Drawing.Size(136, 28);
            this.cboSemestre.TabIndex = 7;
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Location = new System.Drawing.Point(381, 240);
            this.lblDescricao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(80, 20);
            this.lblDescricao.TabIndex = 4;
            this.lblDescricao.Text = "Descrição";
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(385, 263);
            this.txtDescricao.MaxLength = 60;
            this.txtDescricao.Multiline = true;
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescricao.Size = new System.Drawing.Size(613, 155);
            this.txtDescricao.TabIndex = 5;
            // 
            // lblPreRequisitos
            // 
            this.lblPreRequisitos.AutoSize = true;
            this.lblPreRequisitos.Location = new System.Drawing.Point(381, 421);
            this.lblPreRequisitos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPreRequisitos.Name = "lblPreRequisitos";
            this.lblPreRequisitos.Size = new System.Drawing.Size(113, 20);
            this.lblPreRequisitos.TabIndex = 4;
            this.lblPreRequisitos.Text = "Pré-Requisitos";
            // 
            // txtPreRequisitos
            // 
            this.txtPreRequisitos.Location = new System.Drawing.Point(385, 444);
            this.txtPreRequisitos.MaxLength = 60;
            this.txtPreRequisitos.Multiline = true;
            this.txtPreRequisitos.Name = "txtPreRequisitos";
            this.txtPreRequisitos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPreRequisitos.Size = new System.Drawing.Size(613, 99);
            this.txtPreRequisitos.TabIndex = 5;
            // 
            // frmDisciplina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 566);
            this.Controls.Add(this.cboSemestre);
            this.Controls.Add(this.barDisciplina);
            this.Controls.Add(this.txtCargaHoraria);
            this.Controls.Add(this.txtSigla);
            this.Controls.Add(this.txtDescricao);
            this.Controls.Add(this.txtPreRequisitos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblSemestre);
            this.Controls.Add(this.lblCargaHoraria);
            this.Controls.Add(this.lblPreRequisitos);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblSigla);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.grdDados);
            this.Controls.Add(this.chkObrigatoria);
            this.Controls.Add(this.chkPratica);
            this.Controls.Add(this.chkTeorica);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDisciplina";
            this.Text = "Manutenção de Disciplinas";
            this.Load += new System.EventHandler(this.frmDisciplina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdDados)).EndInit();
            this.barDisciplina.ResumeLayout(false);
            this.barDisciplina.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkTeorica;
        private System.Windows.Forms.CheckBox chkPratica;
        private System.Windows.Forms.CheckBox chkObrigatoria;
        private System.Windows.Forms.DataGridView grdDados;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.ToolStrip barDisciplina;
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnAlterar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.Label lblSigla;
        private System.Windows.Forms.TextBox txtSigla;
        private System.Windows.Forms.Label lblCargaHoraria;
        private System.Windows.Forms.TextBox txtCargaHoraria;
        private System.Windows.Forms.Label lblSemestre;
        private System.Windows.Forms.ComboBox cboSemestre;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.Label lblPreRequisitos;
        private System.Windows.Forms.TextBox txtPreRequisitos;
    }
}