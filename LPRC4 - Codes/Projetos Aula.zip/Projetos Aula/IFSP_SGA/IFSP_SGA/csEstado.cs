﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace IFSP_SGA
{
    public class csEstado
    {
        private Int32 idEstado;
        private string nomeEstado;
        private string siglaEstado;

        private conexaoMySql conexao = new conexaoMySql();

        public void setEstadoId (Int32 valor)
        {
            idEstado = valor;
        }
        public Int32 getEstadoId ()
        {
            return idEstado;
        }

        public void setNomeEstado (string valor)
        {
            nomeEstado = valor;
        }
        public string getNomeEstado ()
        {
            return nomeEstado;
        }

        public void setSiglaEstado (string valor)
        {
            siglaEstado = valor;
        }
        public string getSiglaEstado ()
        {
            return siglaEstado;
        }

        public void inserir ()
        {
            string sql = "INSERT INTO estado(estadonome, estadosigla) VALUES (";
            sql += "'" + nomeEstado + "', ";
            sql += "'" + siglaEstado + "'";
            sql += ")";
            conexao.executarSql(sql);
        }

        public void delete ()
        {
            string sql = "DELETE FROM estado WHERE estadoid = " + idEstado.ToString() + ";";
            conexao.executarSql(sql);
        }

        public void update ()
        {
            string sql = "UPDATE estado SET ";
            sql += "estadonome = '" + nomeEstado + "', ";
            sql += "estadosigla = '" + siglaEstado + "' ";
            sql += "WHERE estadoid = " + idEstado + ";";
            conexao.executarSql(sql);
        }

        public DataTable select()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable tabela = new DataTable();
            string sql = "SELECT estadoid, estadonome from estado;";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(tabela);
            return tabela;
        }

        public void selectEstado()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataSet = new DataSet();
            string sql = "SELECT estadonome, estadosigla FROM estado WHERE estadoid = " + idEstado.ToString() + ";";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataSet);

            nomeEstado = dataSet.Tables[0].Rows[0][0].ToString();
            siglaEstado = dataSet.Tables[0].Rows[0][1].ToString();
        }
    }
}
