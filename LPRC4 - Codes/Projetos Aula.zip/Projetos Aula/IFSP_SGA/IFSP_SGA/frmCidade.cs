﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IFSP_SGA
{
    public partial class frmCidade : Form
    {
        csCidade cidade = new csCidade();

        private void habilitaControles(bool status)
        {
            txtNome.Enabled = status;
            txtBairro.Enabled = status;
            txtLogradouro.Enabled = status;
            txtComplemento.Enabled = status;
            txtCEP.Enabled = status;
            txtNumero.Enabled = status;
            txtDescricao.Enabled = status;

        }
        private void gerenciaBotoesBarra(bool status)
        {
            btnNovo.Enabled = status;
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;
            btnSair.Enabled = status;
            btnSalvar.Enabled = !status;
            btnCancelar.Enabled = !status;
        }

        private void limparControles()
        {
            cidade.setCityId(0);
            txtNome.Text = "";
            txtBairro.Text= "";
            txtLogradouro.Text = "";
            txtComplemento.Text = "";
            txtCEP.Text = "";
            txtNumero.Text = "";
            txtDescricao.Text = "";
        }

        private void formataGrid()
        {
            grdDados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdDados.Columns[0].HeaderText = "Código";
            grdDados.Columns[1].HeaderText = "Nome da Cidade";

            grdDados.Columns[0].Width = 0;
            grdDados.Columns[1].Width = 300;
        }

        private void preencheGrid()
        {
            grdDados.DataSource = cidade.select();
            formataGrid();
        }

        private void preencheDadosControles()
        {
            cidade.selectCidade();

            txtNome.Text = cidade.getCityNome();
            txtBairro.Text = cidade.getCityBairro();
            txtLogradouro.Text = cidade.getLogradouroCity();
            txtComplemento.Text = cidade.getComplementoCity();
            txtCEP.Text = cidade.getCEPCity();
            txtNumero.Text = cidade.getNumeroCity();
            txtDescricao.Text = cidade.getDescricaoCity();
        }
        private bool validaDados()
        {
            if (txtNome.Text.Trim().Length <= 1)
            {
                MessageBox.Show("Nome da Cidade é obrigatório, informe!", "Aviso!!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNome.Focus(); // Cursor na caixa de texto do nome
                return false;
            }
            return true;
        }

        private void salvarCidade()
        {
            cidade.setCityNome(txtNome.Text);
            cidade.setCityBairro(txtBairro.Text);
            cidade.setLogradouroCity(txtLogradouro.Text);
            cidade.setComplementoCity(txtComplemento.Text);
            cidade.setCEPCity(txtCEP.Text);
            cidade.setNumeroCity(txtNumero.Text);
            cidade.setDescricaoCity(txtDescricao.Text);

            if (cidade.getCityId() == 0)
            {
                cidade.inserir();
            }
            else
            {
                cidade.update();
            }
        }

        private void excluiCidade()
        {
            cidade.delete();
        }
        public frmCidade()
        {
            InitializeComponent();
        }

        private void frmCidade_Load(object sender, EventArgs e)
        {
            habilitaControles(false);
            gerenciaBotoesBarra(true);
            preencheGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            limparControles();
            gerenciaBotoesBarra(false);
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            gerenciaBotoesBarra(false);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (validaDados() == true)
            {
                salvarCidade();
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
                preencheGrid();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja cancelar a manutenção da Cidade?", "Aviso!!!",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if(cidade.getCityId() != 0)
            {
                DialogResult retorno = MessageBox.Show("Deseja excluir a cidade selecionada?", "Exclusão",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (retorno == DialogResult.Yes)
                {
                    excluiCidade();
                    limparControles();
                    preencheGrid();
                }
            }
            else
            {
                    MessageBox.Show("Selecione a Cidade para excluir", "Aviso!!!", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
            }         
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void grdDados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // seleciona o índice da linha selecionada -> 'grdDados.CurrentRow.Index'
            cidade.setCityId(Convert.ToInt32(grdDados.Rows[grdDados.CurrentRow.Index].Cells[0].Value.ToString()));
            preencheDadosControles();
        }
    }
}

