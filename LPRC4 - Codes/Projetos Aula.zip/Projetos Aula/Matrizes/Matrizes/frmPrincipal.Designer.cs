﻿
namespace Matrizes
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRA = new System.Windows.Forms.Label();
            this.txtRA = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblP1 = new System.Windows.Forms.Label();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.lblP2 = new System.Windows.Forms.Label();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.lblT1 = new System.Windows.Forms.Label();
            this.txtT1 = new System.Windows.Forms.TextBox();
            this.lblT2 = new System.Windows.Forms.Label();
            this.txtT2 = new System.Windows.Forms.TextBox();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.lblMedia = new System.Windows.Forms.Label();
            this.txtMedia = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnPrimeiro = new System.Windows.Forms.Button();
            this.btnAnterior = new System.Windows.Forms.Button();
            this.btnProximo = new System.Windows.Forms.Button();
            this.btnUltimo = new System.Windows.Forms.Button();
            this.lbl_indice = new System.Windows.Forms.Label();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRA
            // 
            this.lblRA.AutoSize = true;
            this.lblRA.Location = new System.Drawing.Point(12, 9);
            this.lblRA.Name = "lblRA";
            this.lblRA.Size = new System.Drawing.Size(32, 20);
            this.lblRA.TabIndex = 0;
            this.lblRA.Text = "RA";
            // 
            // txtRA
            // 
            this.txtRA.Location = new System.Drawing.Point(16, 32);
            this.txtRA.Name = "txtRA";
            this.txtRA.Size = new System.Drawing.Size(88, 26);
            this.txtRA.TabIndex = 1;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(106, 9);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(118, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Aluno";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(110, 32);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(302, 26);
            this.txtNome.TabIndex = 1;
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(414, 8);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(28, 20);
            this.lblP1.TabIndex = 0;
            this.lblP1.Text = "P1";
            // 
            // txtP1
            // 
            this.txtP1.Location = new System.Drawing.Point(418, 32);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(62, 26);
            this.txtP1.TabIndex = 2;
            this.txtP1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtP1_KeyPress);
            this.txtP1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtP1_KeyUp);
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(482, 8);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(28, 20);
            this.lblP2.TabIndex = 0;
            this.lblP2.Text = "P2";
            // 
            // txtP2
            // 
            this.txtP2.Location = new System.Drawing.Point(486, 32);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(62, 26);
            this.txtP2.TabIndex = 2;
            this.txtP2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtP2_KeyPress);
            this.txtP2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtP2_KeyUp);
            // 
            // lblT1
            // 
            this.lblT1.AutoSize = true;
            this.lblT1.Location = new System.Drawing.Point(550, 9);
            this.lblT1.Name = "lblT1";
            this.lblT1.Size = new System.Drawing.Size(27, 20);
            this.lblT1.TabIndex = 0;
            this.lblT1.Text = "T1";
            // 
            // txtT1
            // 
            this.txtT1.Location = new System.Drawing.Point(554, 32);
            this.txtT1.Name = "txtT1";
            this.txtT1.Size = new System.Drawing.Size(62, 26);
            this.txtT1.TabIndex = 2;
            this.txtT1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtT1_KeyPress);
            this.txtT1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtT1_KeyUp);
            // 
            // lblT2
            // 
            this.lblT2.AutoSize = true;
            this.lblT2.Location = new System.Drawing.Point(618, 8);
            this.lblT2.Name = "lblT2";
            this.lblT2.Size = new System.Drawing.Size(27, 20);
            this.lblT2.TabIndex = 0;
            this.lblT2.Text = "T2";
            // 
            // txtT2
            // 
            this.txtT2.Location = new System.Drawing.Point(622, 32);
            this.txtT2.Name = "txtT2";
            this.txtT2.Size = new System.Drawing.Size(62, 26);
            this.txtT2.TabIndex = 2;
            this.txtT2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtT2_KeyPress);
            this.txtT2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtT2_KeyUp);
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Location = new System.Drawing.Point(686, 8);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(74, 20);
            this.lblFaltas.TabIndex = 0;
            this.lblFaltas.Text = "Nº Faltas";
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(690, 32);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(62, 26);
            this.txtFaltas.TabIndex = 2;
            this.txtFaltas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFaltas_KeyPress);
            this.txtFaltas.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtFaltas_KeyUp);
            // 
            // lblMedia
            // 
            this.lblMedia.AutoSize = true;
            this.lblMedia.Location = new System.Drawing.Point(790, 8);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(52, 20);
            this.lblMedia.TabIndex = 0;
            this.lblMedia.Text = "Média";
            // 
            // txtMedia
            // 
            this.txtMedia.Location = new System.Drawing.Point(794, 32);
            this.txtMedia.Name = "txtMedia";
            this.txtMedia.Size = new System.Drawing.Size(62, 26);
            this.txtMedia.TabIndex = 2;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(874, 35);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(65, 20);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "status...";
            // 
            // btnPrimeiro
            // 
            this.btnPrimeiro.Location = new System.Drawing.Point(144, 81);
            this.btnPrimeiro.Name = "btnPrimeiro";
            this.btnPrimeiro.Size = new System.Drawing.Size(80, 40);
            this.btnPrimeiro.TabIndex = 3;
            this.btnPrimeiro.Text = "<<";
            this.btnPrimeiro.UseVisualStyleBackColor = true;
            this.btnPrimeiro.Click += new System.EventHandler(this.btnPrimeiro_Click);
            // 
            // btnAnterior
            // 
            this.btnAnterior.Location = new System.Drawing.Point(230, 81);
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.Size = new System.Drawing.Size(80, 40);
            this.btnAnterior.TabIndex = 3;
            this.btnAnterior.Text = "<";
            this.btnAnterior.UseVisualStyleBackColor = true;
            this.btnAnterior.Click += new System.EventHandler(this.btnAnterior_Click);
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(376, 81);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(80, 40);
            this.btnProximo.TabIndex = 3;
            this.btnProximo.Text = ">";
            this.btnProximo.UseVisualStyleBackColor = true;
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // btnUltimo
            // 
            this.btnUltimo.Location = new System.Drawing.Point(462, 81);
            this.btnUltimo.Name = "btnUltimo";
            this.btnUltimo.Size = new System.Drawing.Size(80, 40);
            this.btnUltimo.TabIndex = 3;
            this.btnUltimo.Text = ">>";
            this.btnUltimo.UseVisualStyleBackColor = true;
            this.btnUltimo.Click += new System.EventHandler(this.btnUltimo_Click);
            // 
            // lbl_indice
            // 
            this.lbl_indice.AutoSize = true;
            this.lbl_indice.Location = new System.Drawing.Point(331, 91);
            this.lbl_indice.Name = "lbl_indice";
            this.lbl_indice.Size = new System.Drawing.Size(27, 20);
            this.lbl_indice.TabIndex = 0;
            this.lbl_indice.Text = "00";
            // 
            // btnNovo
            // 
            this.btnNovo.Location = new System.Drawing.Point(681, 81);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(80, 40);
            this.btnNovo.TabIndex = 3;
            this.btnNovo.Text = "Novo";
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(767, 81);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(80, 40);
            this.btnSalvar.TabIndex = 3;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 149);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.btnNovo);
            this.Controls.Add(this.btnUltimo);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.btnAnterior);
            this.Controls.Add(this.btnPrimeiro);
            this.Controls.Add(this.txtMedia);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblMedia);
            this.Controls.Add(this.txtT2);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.txtT1);
            this.Controls.Add(this.lblT2);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.lblT1);
            this.Controls.Add(this.txtP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lbl_indice);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtRA);
            this.Controls.Add(this.lblRA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmPrincipal";
            this.Text = "SGA - Sistema de Gerenciamento de Alunos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRA;
        private System.Windows.Forms.TextBox txtRA;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.Label lblT1;
        private System.Windows.Forms.TextBox txtT1;
        private System.Windows.Forms.Label lblT2;
        private System.Windows.Forms.TextBox txtT2;
        private System.Windows.Forms.Label lblFaltas;
        private System.Windows.Forms.TextBox txtFaltas;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.TextBox txtMedia;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnPrimeiro;
        private System.Windows.Forms.Button btnAnterior;
        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.Button btnUltimo;
        private System.Windows.Forms.Label lbl_indice;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSalvar;
    }
}

