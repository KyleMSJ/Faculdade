--material_contrução

CREATE TABLE produto (
	id int, 
	nome varchar(50) NOT NULL,
	descricao varchar(255),
	qtd int NOT NULL,
)

CREATE TABLE cidade (
	id int,
	nome varchar(35) NOT NULL,
	bairro varchar(35),
	CEP varchar (35) NOT NULL,
	numero varchar (35) NOT NULL,
	complemento varchar(35),
)

CREATE TABLE estado (
	id int,
	nome varchar (35),
	int sigla (30) NOT NULL,
	PRIMARY KEY (id)
)

ALTER TABLE pedido ADD FOREIGN KEY (idCliente) REFERENCES cliente (CPF) ON UPDATE CASCADE ON DELETE CASCADE // chave estrangeira