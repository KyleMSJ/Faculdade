﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mensagem
{
    public partial class frmPrincipal : Form
    {
        string[] mensagem = new string[5];

        Int16[] numero = { 10, 20, 30, 40, 50 };

        string[] mensagens =
        {
            "Nunca está errado fazendo a coisa certa",
            "Bom dia, seja feliz",
            "Uma ótima semana",
            "Saiu o pagamento, vamos comemorar",
            "Amanhã é feriado"
        };

        private void defineMensagens()
        {
            mensagem[0] = "Mensagem 01";
            mensagem[1] = "Mensagem 02";
            mensagem[2] = "Mensagem 03";
            mensagem[3] = "Mensagem 04";
            mensagem[4] = "Mensagem 05";

            //mensagem[0] = mensagens[4];
        }
        private void exibeMensagem ()
        {
            Random randomico = new Random(); // declaração da variável 
            Int16 posicao;

            posicao = Convert.ToInt16(randomico.Next(5)); // Retorna um valor menor que 5
            //posicao = Convert.ToInt16(randomico.Next(10,20)); - Retorna um valor entre 10 e 20*/
            //posicao = Convert.ToInt16(randomico.Next()); - Retorna um valor de 0 até o infinito
            //txtMensagem.Text = mensagens[posicao];
            txtMensagem.Text = mensagem[posicao] + " - " + mensagens[posicao];


        }
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnMostraMensagem_Click(object sender, EventArgs e)
        {
            exibeMensagem();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            defineMensagens();
            exibeMensagem(); // no carregamento do formulário, automaticamente já traz uma mensagem
        }
    }
}
