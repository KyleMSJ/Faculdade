﻿
namespace mensagem
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMensagem = new System.Windows.Forms.TextBox();
            this.btnMostraMensagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMensagem
            // 
            this.txtMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMensagem.Location = new System.Drawing.Point(12, 12);
            this.txtMensagem.Multiline = true;
            this.txtMensagem.Name = "txtMensagem";
            this.txtMensagem.Size = new System.Drawing.Size(686, 204);
            this.txtMensagem.TabIndex = 0;
            // 
            // btnMostraMensagem
            // 
            this.btnMostraMensagem.Location = new System.Drawing.Point(12, 222);
            this.btnMostraMensagem.Name = "btnMostraMensagem";
            this.btnMostraMensagem.Size = new System.Drawing.Size(107, 41);
            this.btnMostraMensagem.TabIndex = 1;
            this.btnMostraMensagem.Text = "Mostra Mensagem";
            this.btnMostraMensagem.UseVisualStyleBackColor = true;
            this.btnMostraMensagem.Click += new System.EventHandler(this.btnMostraMensagem_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 275);
            this.Controls.Add(this.btnMostraMensagem);
            this.Controls.Add(this.txtMensagem);
            this.Name = "frmPrincipal";
            this.Text = "Mensagem Diária";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMensagem;
        private System.Windows.Forms.Button btnMostraMensagem;
    }
}

