﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Matrizes
{
    public partial class frmPrincipal : Form
    {
        private struct aluno // Funcionamento da matriz, mas com informações definidas do tipo desejado
        {
            public Int32 ra;
            public string nome;
            public double prova1;
            public double prova2;
            public double trabalho1;
            public double trabalho2;
            public Int16 faltas;
        }

        //private aluno cadAluno; - pega toda a estrutura para um único aluno 
        private aluno[] Alunos = new aluno[10];  
        
        private string[,] alunos = new string[10, 7];
        private Int16 iLinha = -1; // nenhum aluno cadastrado

        private void salvaDadosAlunos()
        {
            if (txtRA.Text != "")
            {
                Alunos[iLinha].ra = Convert.ToInt32(txtRA.Text); //alunos[iLinha, 0] = txtRA.Text;
            }
            Alunos[iLinha].nome = txtNome.Text; //alunos[iLinha, 1] = txtNome.Text;
            if (txtP1.Text != "")
            {
                Alunos[iLinha].prova1 = Convert.ToDouble(txtP1.Text); //alunos[iLinha, 2] = txtP1.Text;
            }
            if (txtP2.Text != "")
            {
                Alunos[iLinha].prova2 = Convert.ToDouble(txtP2.Text); //alunos[iLinha, 3] = txtP2.Text;
            }
            if (txtT1.Text != "")
            {
                Alunos[iLinha].trabalho1 = Convert.ToDouble(txtT1.Text); //alunos[iLinha, 4] = txtT1.Text;
            }
            if (txtT1.Text != "")
            {
                Alunos[iLinha].trabalho2 = Convert.ToDouble(txtT1.Text); //alunos[iLinha, 5] = txtT2.Text;
            }
            if (txtFaltas.Text != "")
            {
                Alunos[iLinha].faltas = Convert.ToInt16(txtFaltas.Text); //alunos[iLinha, 6] = txtFaltas.Text;
            }
        }
        private void exibeDadosAlunos()
        {
            txtRA.Text = Alunos[iLinha].ra.ToString(); //txtRA.Text = alunos[iLinha, 0];
            txtNome.Text = Alunos[iLinha].nome; //txtNome.Text = alunos[iLinha, 1];
            txtP1.Text = Alunos[iLinha].prova1.ToString(); //txtP1.Text = alunos[iLinha, 2];
            txtP2.Text = Alunos[iLinha].prova2.ToString(); //txtP2.Text = alunos[iLinha, 3];
            txtT1.Text = Alunos[iLinha].trabalho1.ToString(); //txtT1.Text = alunos[iLinha, 4];
            txtT2.Text = Alunos[iLinha].trabalho2.ToString(); //txtT2.Text = alunos[iLinha, 5];
            txtFaltas.Text = Alunos[iLinha].faltas.ToString(); //txtFaltas.Text = alunos[iLinha, 6];
            calculaMedia();
        }

        private bool validaIntervaloNota(string nota)
        {
            if (nota != "")
            {
                if (Convert.ToDouble(nota) > 10)
                {
                    MessageBox.Show("Nota está fora do intervalo!!");
                    return false; // não chega no segundo return
                }
            }
            return true;
        }

        private void calculaMedia()
        {
            double media = 0.0;
            if (txtP1.Text != "")
            {
                media += Convert.ToDouble(txtP1.Text);
            }
            if (txtP2.Text != "")
            {
                media += Convert.ToDouble(txtP2.Text);
            }
            if (txtT1.Text != "")
            {
                media += Convert.ToDouble(txtT1.Text);
            }
            if (txtT2.Text != "")
            {
                media += Convert.ToDouble(txtT2.Text);
            }
            media /= 4;

            txtMedia.Text = media.ToString("0.00"); //uma casa inteira, duas casas decimais
            processaStatus();
        }

        private bool processaStatusFalta()
        {
            if (txtFaltas.Text != "")
            {
                if (Convert.ToInt16(txtFaltas.Text) > 40)
                {
                    lblStatus.Text = "Reprovado por falta!!";
                    return true;
                }
            }
            return false;
        }
        private void processaStatus()
        {
            if (processaStatusFalta() == false)
            {
                if (txtMedia.Text != "")
                {
                    if (Convert.ToDouble(txtMedia.Text) >= 7)
                    {
                        lblStatus.Text = "Aprovado!";
                    }
                    else if (Convert.ToDouble(txtMedia.Text) < 4)
                    {
                        lblStatus.Text = "Reprovado!";
                    }
                    else
                    {
                        lblStatus.Text = "Recuperação";
                    }
                }
            }
        }

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            for (Int16 i = 0; i < 10; i++)
            {
                if (Alunos[i].ra == 0) //alunos[i, 0] == null - matriz
                {
                    iLinha = i;
                    break;
                }
            }
            txtRA.Text = "";
            txtNome.Text = "";
            txtP1.Text = "";
            txtP2.Text = "";
            txtT1.Text = "";
            txtT2.Text = "";
            txtFaltas.Text = "";
            txtMedia.Text = "";
        }

        private void btnPrimeiro_Click(object sender, EventArgs e)
        {
            if (iLinha == -1)
            {
                MessageBox.Show("Não há alunos cadastrados!!!");
            }
            else
            {
                iLinha = 0;
                exibeDadosAlunos();
            }

        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (iLinha == -1)
            {
                MessageBox.Show("Não há alunos cadastrados!!!");
            }
            else
            {
                if (iLinha != 0)
                {
                    iLinha--;
                }
                exibeDadosAlunos();
            }
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (iLinha == -1)
            {
                MessageBox.Show("Não há alunos cadastrados!!!");
            }
            else
            {
                if (iLinha != 9) // if (iLinha < 9)
                {
                    iLinha++;
                }
                exibeDadosAlunos();
            }
        }

        private void btnUltimo_Click(object sender, EventArgs e)
        {
            if (iLinha == -1)
            {
                MessageBox.Show("Não há alunos cadastrados!!!");
            }
            else
            {
                iLinha = 9;
                exibeDadosAlunos();
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (iLinha != -1)
            {
                salvaDadosAlunos();
            }
            else
                MessageBox.Show("Clique antes no botão 'Novo'");
        }

        private void txtP1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Se a tecla pressionada NÃO (!) for um número, for diferente da tecla 'BACKSPACE'
            //E diferente da tecla ','
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44)

            {
                e.Handled = true; // ignora qualquer tecla que não seja número / backspace / ,
            }
            if (e.KeyChar == 44)
            {
                if (txtP1.Text.Contains(","))
                {
                    e.Handled = true;
                }
            }
        }

        private void txtP2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44)

            {
                e.Handled = true;
            }
            if (e.KeyChar == 44)
            {
                if (txtP2.Text.Contains(","))
                {
                    e.Handled = true;
                }
            }
        }

        private void txtT1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44)

            {
                e.Handled = true;
            }
            if (e.KeyChar == 44)
            {
                if (txtT1.Text.Contains(","))
                {
                    e.Handled = true;
                }
            }
        }
        private void txtT2_KeyPress(object sender, KeyPressEventArgs e)
        {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44)
                {
                    e.Handled = true;
                }
                if (e.KeyChar == 44)
                {
                    if (txtT2.Text.Contains(","))
                    {
                        e.Handled = true;
                    }
                }
        }

        private void txtFaltas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtP1_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtP1.Text == ",")
            {
                txtP1.Text = "0,";
                txtP1.SelectionStart = txtP1.Text.Length; // O cursor vai para a última posição
            }                                             // (neste caso) para o usuário continuar
                                                          // digitando após a virgula  
            if (validaIntervaloNota(txtP1.Text) == false)
            {
                txtP1.Text = "";
            }
            calculaMedia();
        }

        private void txtP2_KeyUp(object sender, KeyEventArgs e)
        {
            if (validaIntervaloNota(txtP2.Text) == false)
            {
                txtP2.Text = "";
            }
            calculaMedia();
        }

        private void txtT1_KeyUp(object sender, KeyEventArgs e)
        {
            if (validaIntervaloNota(txtT1.Text) == false)
            {
                txtT1.Text = "";
            }
            calculaMedia();
        }

        private void txtT2_KeyUp(object sender, KeyEventArgs e)
        {
            if (validaIntervaloNota(txtT2.Text) == false)
            {
                txtT2.Text = "";
            }
            calculaMedia();
        }

        private void txtFaltas_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtFaltas.Text != "")
            {
                processaStatus();
            }
        }
    }
} 

