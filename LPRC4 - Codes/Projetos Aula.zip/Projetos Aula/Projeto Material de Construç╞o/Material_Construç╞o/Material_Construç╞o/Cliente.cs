﻿using System;

public class Class1
{
	public class csCliente()
	{
	private Int32 idCliente;
	private string nome;
	private string CPF;
	private string CEP;
	private string telefone;
	private string cidade;
	private Int16 sigla; // ComboBox - estado
	private string numero;
	}
}
