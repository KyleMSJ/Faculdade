﻿namespace Material_Construção
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
