﻿CREATE TABLE cliente(
    CPF char(14),
    nome varchar(60) NOT NULL,
    CEP varchar(10),
    cidade varchar(40),
    estado char(2),
    numero int,
    telefone varchar(15),
    PRIMARY KEY (CPF)
);

485.504.498-90
13505-600

