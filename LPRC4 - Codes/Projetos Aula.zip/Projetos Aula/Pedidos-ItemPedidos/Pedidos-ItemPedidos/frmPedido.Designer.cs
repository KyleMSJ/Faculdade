﻿
namespace Pedidos_ItemPedidos
{
    partial class frmPedidos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPedidos));
            this.mnuPedido = new System.Windows.Forms.ToolStrip();
            this.btnPedidoNovo = new System.Windows.Forms.ToolStripButton();
            this.btnPedidoAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnPedidoExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnPedidoSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnPedidoCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnPedidoSair = new System.Windows.Forms.ToolStripButton();
            this.grdPedido = new System.Windows.Forms.DataGridView();
            this.cboCliente = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboFuncionario = new System.Windows.Forms.ComboBox();
            this.mnuItemPedido = new System.Windows.Forms.ToolStrip();
            this.btnItemPedidoNovo = new System.Windows.Forms.ToolStripButton();
            this.btnItemPedidoAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnItemPedidoExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnItemPedidoSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnItemPedidoCancelar = new System.Windows.Forms.ToolStripButton();
            this.grdItemPedido = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.cboProduto = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtQtde = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtValorTotal = new System.Windows.Forms.TextBox();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.txtValorPedido = new System.Windows.Forms.TextBox();
            this.mnuPedido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdPedido)).BeginInit();
            this.mnuItemPedido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdItemPedido)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuPedido
            // 
            this.mnuPedido.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.mnuPedido.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnPedidoNovo,
            this.btnPedidoAlterar,
            this.btnPedidoExcluir,
            this.btnPedidoSalvar,
            this.btnPedidoCancelar,
            this.btnPedidoSair});
            this.mnuPedido.Location = new System.Drawing.Point(0, 0);
            this.mnuPedido.Name = "mnuPedido";
            this.mnuPedido.Size = new System.Drawing.Size(774, 55);
            this.mnuPedido.TabIndex = 0;
            // 
            // btnPedidoNovo
            // 
            this.btnPedidoNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoNovo.Image")));
            this.btnPedidoNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoNovo.Name = "btnPedidoNovo";
            this.btnPedidoNovo.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoNovo.Click += new System.EventHandler(this.btnPedidoNovo_Click);
            // 
            // btnPedidoAlterar
            // 
            this.btnPedidoAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoAlterar.Image")));
            this.btnPedidoAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoAlterar.Name = "btnPedidoAlterar";
            this.btnPedidoAlterar.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoAlterar.Click += new System.EventHandler(this.btnPedidoAlterar_Click);
            // 
            // btnPedidoExcluir
            // 
            this.btnPedidoExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoExcluir.Image")));
            this.btnPedidoExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoExcluir.Name = "btnPedidoExcluir";
            this.btnPedidoExcluir.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoExcluir.Click += new System.EventHandler(this.btnPedidoExcluir_Click);
            // 
            // btnPedidoSalvar
            // 
            this.btnPedidoSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoSalvar.Image")));
            this.btnPedidoSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoSalvar.Name = "btnPedidoSalvar";
            this.btnPedidoSalvar.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoSalvar.Text = "toolStripButton4";
            this.btnPedidoSalvar.Click += new System.EventHandler(this.btnPedidoSalvar_Click);
            // 
            // btnPedidoCancelar
            // 
            this.btnPedidoCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoCancelar.Image")));
            this.btnPedidoCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoCancelar.Name = "btnPedidoCancelar";
            this.btnPedidoCancelar.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoCancelar.Text = "toolStripButton5";
            this.btnPedidoCancelar.Click += new System.EventHandler(this.btnPedidoCancelar_Click);
            // 
            // btnPedidoSair
            // 
            this.btnPedidoSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPedidoSair.Image = ((System.Drawing.Image)(resources.GetObject("btnPedidoSair.Image")));
            this.btnPedidoSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPedidoSair.Name = "btnPedidoSair";
            this.btnPedidoSair.Size = new System.Drawing.Size(52, 52);
            this.btnPedidoSair.Text = "toolStripButton6";
            this.btnPedidoSair.Click += new System.EventHandler(this.btnPedidoSair_Click);
            // 
            // grdPedido
            // 
            this.grdPedido.AllowUserToAddRows = false;
            this.grdPedido.AllowUserToDeleteRows = false;
            this.grdPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdPedido.Location = new System.Drawing.Point(9, 58);
            this.grdPedido.Name = "grdPedido";
            this.grdPedido.ReadOnly = true;
            this.grdPedido.RowHeadersWidth = 51;
            this.grdPedido.RowTemplate.Height = 24;
            this.grdPedido.Size = new System.Drawing.Size(313, 437);
            this.grdPedido.TabIndex = 1;
            this.grdPedido.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdPedido_CellClick);
            // 
            // cboCliente
            // 
            this.cboCliente.FormattingEnabled = true;
            this.cboCliente.Location = new System.Drawing.Point(331, 82);
            this.cboCliente.Name = "cboCliente";
            this.cboCliente.Size = new System.Drawing.Size(321, 24);
            this.cboCliente.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(331, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(658, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Data";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(661, 82);
            this.txtData.Mask = "00/00/0000";
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(101, 22);
            this.txtData.TabIndex = 5;
            this.txtData.ValidatingType = typeof(System.DateTime);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Funcionário";
            // 
            // cboFuncionario
            // 
            this.cboFuncionario.FormattingEnabled = true;
            this.cboFuncionario.Location = new System.Drawing.Point(331, 139);
            this.cboFuncionario.Name = "cboFuncionario";
            this.cboFuncionario.Size = new System.Drawing.Size(321, 24);
            this.cboFuncionario.TabIndex = 7;
            // 
            // mnuItemPedido
            // 
            this.mnuItemPedido.Dock = System.Windows.Forms.DockStyle.None;
            this.mnuItemPedido.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.mnuItemPedido.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnItemPedidoNovo,
            this.btnItemPedidoAlterar,
            this.btnItemPedidoExcluir,
            this.btnItemPedidoSalvar,
            this.btnItemPedidoCancelar});
            this.mnuItemPedido.Location = new System.Drawing.Point(332, 234);
            this.mnuItemPedido.Name = "mnuItemPedido";
            this.mnuItemPedido.Size = new System.Drawing.Size(273, 55);
            this.mnuItemPedido.TabIndex = 8;
            // 
            // btnItemPedidoNovo
            // 
            this.btnItemPedidoNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnItemPedidoNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnItemPedidoNovo.Image")));
            this.btnItemPedidoNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnItemPedidoNovo.Name = "btnItemPedidoNovo";
            this.btnItemPedidoNovo.Size = new System.Drawing.Size(52, 52);
            this.btnItemPedidoNovo.Click += new System.EventHandler(this.btnItemPedidoNovo_Click);
            // 
            // btnItemPedidoAlterar
            // 
            this.btnItemPedidoAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnItemPedidoAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnItemPedidoAlterar.Image")));
            this.btnItemPedidoAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnItemPedidoAlterar.Name = "btnItemPedidoAlterar";
            this.btnItemPedidoAlterar.Size = new System.Drawing.Size(52, 52);
            this.btnItemPedidoAlterar.Click += new System.EventHandler(this.btnItemPedidoAlterar_Click);
            // 
            // btnItemPedidoExcluir
            // 
            this.btnItemPedidoExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnItemPedidoExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnItemPedidoExcluir.Image")));
            this.btnItemPedidoExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnItemPedidoExcluir.Name = "btnItemPedidoExcluir";
            this.btnItemPedidoExcluir.Size = new System.Drawing.Size(52, 52);
            this.btnItemPedidoExcluir.Click += new System.EventHandler(this.btnItemPedidoExcluir_Click);
            // 
            // btnItemPedidoSalvar
            // 
            this.btnItemPedidoSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnItemPedidoSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnItemPedidoSalvar.Image")));
            this.btnItemPedidoSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnItemPedidoSalvar.Name = "btnItemPedidoSalvar";
            this.btnItemPedidoSalvar.Size = new System.Drawing.Size(52, 52);
            this.btnItemPedidoSalvar.Text = "toolStripButton4";
            this.btnItemPedidoSalvar.Click += new System.EventHandler(this.btnItemPedidoSalvar_Click);
            // 
            // btnItemPedidoCancelar
            // 
            this.btnItemPedidoCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnItemPedidoCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnItemPedidoCancelar.Image")));
            this.btnItemPedidoCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnItemPedidoCancelar.Name = "btnItemPedidoCancelar";
            this.btnItemPedidoCancelar.Size = new System.Drawing.Size(52, 52);
            this.btnItemPedidoCancelar.Text = "toolStripButton5";
            this.btnItemPedidoCancelar.Click += new System.EventHandler(this.btnItemPedidoCancelar_Click);
            // 
            // grdItemPedido
            // 
            this.grdItemPedido.AllowUserToAddRows = false;
            this.grdItemPedido.AllowUserToDeleteRows = false;
            this.grdItemPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdItemPedido.Location = new System.Drawing.Point(334, 292);
            this.grdItemPedido.Name = "grdItemPedido";
            this.grdItemPedido.ReadOnly = true;
            this.grdItemPedido.RowHeadersWidth = 51;
            this.grdItemPedido.RowTemplate.Height = 24;
            this.grdItemPedido.Size = new System.Drawing.Size(405, 107);
            this.grdItemPedido.TabIndex = 9;
            this.grdItemPedido.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdItemPedido_CellClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(331, 414);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Produto";
            // 
            // cboProduto
            // 
            this.cboProduto.FormattingEnabled = true;
            this.cboProduto.Location = new System.Drawing.Point(334, 438);
            this.cboProduto.Name = "cboProduto";
            this.cboProduto.Size = new System.Drawing.Size(240, 24);
            this.cboProduto.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(583, 414);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Quantidade";
            // 
            // txtQtde
            // 
            this.txtQtde.Location = new System.Drawing.Point(586, 438);
            this.txtQtde.Name = "txtQtde";
            this.txtQtde.Size = new System.Drawing.Size(127, 22);
            this.txtQtde.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(331, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Valor Total";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(445, 177);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Desconto";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(560, 177);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "Valor do Pedido";
            // 
            // txtValorTotal
            // 
            this.txtValorTotal.Location = new System.Drawing.Point(331, 201);
            this.txtValorTotal.Name = "txtValorTotal";
            this.txtValorTotal.Size = new System.Drawing.Size(100, 22);
            this.txtValorTotal.TabIndex = 17;
            // 
            // txtDesconto
            // 
            this.txtDesconto.Location = new System.Drawing.Point(448, 201);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(100, 22);
            this.txtDesconto.TabIndex = 18;
            // 
            // txtValorPedido
            // 
            this.txtValorPedido.Location = new System.Drawing.Point(563, 201);
            this.txtValorPedido.Name = "txtValorPedido";
            this.txtValorPedido.Size = new System.Drawing.Size(100, 22);
            this.txtValorPedido.TabIndex = 19;
            // 
            // frmPedidos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 507);
            this.Controls.Add(this.txtValorPedido);
            this.Controls.Add(this.txtDesconto);
            this.Controls.Add(this.txtValorTotal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtQtde);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cboProduto);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.grdItemPedido);
            this.Controls.Add(this.mnuItemPedido);
            this.Controls.Add(this.cboFuncionario);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboCliente);
            this.Controls.Add(this.grdPedido);
            this.Controls.Add(this.mnuPedido);
            this.Name = "frmPedidos";
            this.Text = "Pedidos";
            this.Load += new System.EventHandler(this.frmPedidos_Load);
            this.mnuPedido.ResumeLayout(false);
            this.mnuPedido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdPedido)).EndInit();
            this.mnuItemPedido.ResumeLayout(false);
            this.mnuItemPedido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdItemPedido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip mnuPedido;
        private System.Windows.Forms.ToolStripButton btnPedidoNovo;
        private System.Windows.Forms.ToolStripButton btnPedidoAlterar;
        private System.Windows.Forms.ToolStripButton btnPedidoExcluir;
        private System.Windows.Forms.ToolStripButton btnPedidoSalvar;
        private System.Windows.Forms.ToolStripButton btnPedidoCancelar;
        private System.Windows.Forms.ToolStripButton btnPedidoSair;
        private System.Windows.Forms.DataGridView grdPedido;
        private System.Windows.Forms.ComboBox cboCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txtData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboFuncionario;
        private System.Windows.Forms.ToolStrip mnuItemPedido;
        private System.Windows.Forms.ToolStripButton btnItemPedidoNovo;
        private System.Windows.Forms.ToolStripButton btnItemPedidoAlterar;
        private System.Windows.Forms.ToolStripButton btnItemPedidoExcluir;
        private System.Windows.Forms.ToolStripButton btnItemPedidoSalvar;
        private System.Windows.Forms.ToolStripButton btnItemPedidoCancelar;
        private System.Windows.Forms.DataGridView grdItemPedido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboProduto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtQtde;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtValorTotal;
        private System.Windows.Forms.TextBox txtDesconto;
        private System.Windows.Forms.TextBox txtValorPedido;
    }
}

