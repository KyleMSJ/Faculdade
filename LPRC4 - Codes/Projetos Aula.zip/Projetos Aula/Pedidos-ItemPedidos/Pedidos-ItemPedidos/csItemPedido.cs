﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Pedidos_ItemPedidos
{
    public class csItemPedido
    {
        private Int32 itemPedidoId;
        private Int32 pedidoId;
        private Int32 produtoId;
        private Int32 itemPedidoQtde;

        private conectMySql conexao = new conectMySql();

        public void setitemPedidoId(Int32 valor)
        {
            itemPedidoId = valor;
        }

        public Int32 getitemPedidoId()
        {
            return itemPedidoId;
        }

        public void setPedidoId(Int32 valor)
        {
            pedidoId = valor;
        }

        public Int32 getPedidoId()
        {
            return pedidoId;
        }

        public void setProdutoId(Int32 valor)
        {
            produtoId = valor;
        }

        public Int32 getProdutoId()
        {
            return produtoId;
        }

        public void setItemPedidoQtde(Int32 valor)
        {
            itemPedidoQtde = valor;
        }

        public Int32 getItemPedidoQtde()
        {
            return itemPedidoQtde;
        }

        public void inserir()
        {
            string sql = "INSERT INTO itempedido(pedidoid, produtoid, itempedidoquantidade) VALUES (";
            sql += pedidoId.ToString() + ", " + produtoId.ToString() + ", " + itemPedidoQtde.ToString() + ")";
            conexao.executarSql(sql);
        }

        public void update()
        {
            string sql = "UPDATE itempedido SET pedidoid = " + pedidoId.ToString() + ", produtoid = " + produtoId.ToString() + ", itempedidoquantidade = " + itemPedidoQtde.ToString() + " WHERE itemPedidoId = " + itemPedidoId.ToString();
            conexao.executarSql(sql);
        }

        public void delete()
        {
            string sql = "DELETE FROM itempedido WHERE itemPedidoId = " + itemPedidoId.ToString();
            conexao.executarSql(sql);
        }

        public void deleteAll()
        {
            string sql = "DELETE FROM itempedido WHERE PedidoId = " + pedidoId.ToString();
            conexao.executarSql(sql);
        }

        public DataTable select()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable tabela = new DataTable();
            string sql = "SELECT itempedidoid, pedidoid, produtoid, itempedidoquantidade FROM itempedido";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(tabela);
            return tabela;
        }

        public void selectItemPedido()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataset = new DataSet();
            string sql = "SELECT itempedidoid, pedidoid, produtoid, itempedidoquantidade FROM itempedido WHERE itemPedidoId = " + itemPedidoId.ToString();
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataset);

            itemPedidoId = Convert.ToInt32(dataset.Tables[0].Rows[0][0].ToString());
            pedidoId = Convert.ToInt32(dataset.Tables[0].Rows[0][1].ToString());
            produtoId = Convert.ToInt32(dataset.Tables[0].Rows[0][2].ToString());
            itemPedidoQtde = Convert.ToInt32(dataset.Tables[0].Rows[0][3].ToString());
        }

        public DataSet selectItemPedido_do_Pedido()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataset = new DataSet();
            string sql = "SELECT itempedidoid, codigoid, produtonome, itempedidoquantidade ";
            sql += " FROM itempedido ";
            sql += " inner join produto on itempedido.produtoid = produto.codigoid ";
            sql += "where pedidoid = " + pedidoId.ToString();
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataset);
            return dataset;
        }
    }
}
