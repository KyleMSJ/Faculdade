﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pedidos_ItemPedidos
{
    public partial class frmPedidos : Form
    {
        csPedido pedido = new csPedido();
        csItemPedido itemPedido = new csItemPedido();
        csProduto produto = new csProduto();
        csCliente cliente = new csCliente();
        csFuncionario funcionario = new csFuncionario();

        public frmPedidos()
        {
            InitializeComponent();
        }

        private void PreencheComboboxCliente()
        {
            cboCliente.DataSource = cliente.select();
            cboCliente.DisplayMember = "clienteNome";
            cboCliente.ValueMember = "clienteId";

            cboCliente.SelectedIndex = -1;
        }

        private void PreencheComboboxFuncionario()
        {
            cboFuncionario.DataSource = funcionario.select();
            cboFuncionario.DisplayMember = "funcionarioNome";
            cboFuncionario.ValueMember = "funcionarioId";

            cboFuncionario.SelectedIndex = -1;
        }

        private void PreencheComboboxProduto()
        {
            cboProduto.DataSource = produto.select();
            cboProduto.DisplayMember = "produtonome";
            cboProduto.ValueMember = "codigoid";

            cboProduto.SelectedIndex = -1;
        }

        private void habilitaControlesPedido(bool status)
        {
            cboCliente.Enabled = status;
            txtData.Enabled = status;
            cboFuncionario.Enabled = status;
            txtValorPedido.Enabled = status;
            txtValorTotal.Enabled = status;
            txtDesconto.Enabled = status;

            mnuItemPedido.Enabled = status;
        }

        private void habilitaControlesItemPedido(bool status)
        {
            cboProduto.Enabled = status;
            txtQtde.Enabled = status;
        }

        private void limparControlesPedido()
        {
            pedido.setPedidoId(0);
            cboCliente.SelectedIndex = -1;
            txtData.Text = "";
            cboFuncionario.SelectedIndex = -1;
            txtValorPedido.Text = "";
            txtValorTotal.Text = "";
            txtDesconto.Text = "";
        }


        public void limparControlesItemPedido()
        {
            cboProduto.SelectedIndex = -1;
            txtQtde.Text = "";
        }

        private void gerenciaBotoesBarraPedido(bool status)
        {
            btnPedidoNovo.Enabled = status;
            btnPedidoAlterar.Enabled = status;
            btnPedidoExcluir.Enabled = status;
            btnPedidoSair.Enabled = status;
            btnPedidoSalvar.Enabled = !status;
            btnPedidoCancelar.Enabled = !status;
        }

        private void gerenciaBotoesBarraItemPedido(bool status)
        {
            btnItemPedidoNovo.Enabled = status;
            btnItemPedidoAlterar.Enabled = status;
            btnItemPedidoExcluir.Enabled = status;
            btnItemPedidoSalvar.Enabled = !status;
            btnItemPedidoCancelar.Enabled = !status;
        }

        private void formataGridPedido()
        {
            grdPedido.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdPedido.Columns[0].HeaderText = "Código";
            grdPedido.Columns[1].HeaderText = "Data";
            grdPedido.Columns[2].HeaderText = "Cliente";

            grdPedido.Columns[0].Width = 0;
            grdPedido.Columns[1].Width = 70;
            grdPedido.Columns[2].Width = 260;
        }

        private void formataGridItemPedido()
        {
            grdItemPedido.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdItemPedido.Columns.Add("Codigo", "Codigo");
            grdItemPedido.Columns.Add("Produto", "Nome Produto");
            grdItemPedido.Columns.Add("Qtde", "Qtde");
            grdItemPedido.Columns.Add("Valor", "Valor");
            grdItemPedido.Columns.Add("Total", "Total");

            grdItemPedido.Columns[0].Width = 0;
            grdItemPedido.Columns[1].Width = 100;
            grdItemPedido.Columns[2].Width = 30;
            grdItemPedido.Columns[3].Width = 30;
            grdItemPedido.Columns[4].Width = 30;

        }

        private void preencheGridPedido()
        {
            grdPedido.DataSource = pedido.select();
            formataGridPedido();
        }

        public void preencheGridItemPedido()
        {
            grdItemPedido.Rows.Clear();

            DataSet itens = new DataSet();
            itemPedido.setPedidoId(pedido.getPedidoId());

            itens = itemPedido.selectItemPedido_do_Pedido();

            if (itens.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow linha in itens.Tables[0].Rows)
                {
                    DataGridViewRow item = new DataGridViewRow();
                    item.CreateCells(grdItemPedido);
                    item.Cells[0].Value = linha[1].ToString();
                    item.Cells[1].Value = linha[2].ToString();
                    item.Cells[2].Value = linha[3].ToString();
                    item.Cells[3].Value = "10";
                    item.Cells[4].Value = "40";
                    grdItemPedido.Rows.Add(item);
                }
            }
        }

        private void preencheDadosControlePedido()
        {
            pedido.selectPedido();
            cboCliente.SelectedValue = pedido.getClienteId();
            txtData.Text = pedido.getPedidoData().ToString();
            cboFuncionario.SelectedValue = pedido.getFuncionarioId();
            txtValorPedido.Text = (pedido.getPedidoValor() - pedido.getPedidoDesconto()).ToString();
            txtValorTotal.Text = pedido.getPedidoValor().ToString();
            txtDesconto.Text = pedido.getPedidoDesconto().ToString();
        }

        private void salvarPedido()
        {
            pedido.setClienteId(Convert.ToInt32(cboCliente.SelectedValue));
            pedido.setFuncionarioId(Convert.ToInt32(cboFuncionario.SelectedValue));
            pedido.setPedidoData(Convert.ToDateTime(txtData.Text));
            pedido.setPedidoValor(Convert.ToDouble(txtValorTotal.Text + 1));
            pedido.setPedidoDesconto(Convert.ToDouble(txtDesconto.Text + 1));


            if (pedido.getPedidoId() == 0)
            {
                //Nova Disciplina
                pedido.inserir();


                //busca o ultimo pedido salvo
                pedido.selectPedidoUltimo();
                itemPedido.setPedidoId(pedido.getPedidoId());

                for (int i = 0; i < grdItemPedido.Rows.Count; i++)
                {
                    itemPedido.setItemPedidoQtde(Convert.ToInt32(grdItemPedido.Rows[i].Cells[2].Value.ToString()));
                    itemPedido.setProdutoId(Convert.ToInt32(grdItemPedido.Rows[i].Cells[0].Value.ToString()));
                    itemPedido.inserir();
                }
                grdItemPedido.Rows.Clear();

            }
            else
            {
                //Atualizar disciplina atual
                pedido.update();

                itemPedido.setPedidoId(pedido.getPedidoId());

                itemPedido.deleteAll();

                for (int i = 0; i < grdItemPedido.Rows.Count; i++)
                {
                    itemPedido.setItemPedidoQtde(Convert.ToInt32(grdItemPedido.Rows[i].Cells[2].Value.ToString()));
                    itemPedido.setProdutoId(Convert.ToInt32(grdItemPedido.Rows[i].Cells[0].Value.ToString()));
                    itemPedido.inserir();
                }
                grdItemPedido.Rows.Clear();

            }
        }

        private void excluiPedido()
        {
            pedido.delete();
        }

        private void frmPedidos_Load(object sender, EventArgs e)
        {
            habilitaControlesPedido(false);
            gerenciaBotoesBarraPedido(true);
            preencheGridPedido();

            PreencheComboboxCliente();
            PreencheComboboxFuncionario();
            PreencheComboboxProduto();

            formataGridItemPedido();
            habilitaControlesItemPedido(false);
            gerenciaBotoesBarraItemPedido(true);
        }

        private void btnPedidoSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPedidoCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja cancelar o Pedido?", "Aviso!!!",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                habilitaControlesPedido(false);
                limparControlesPedido();
                gerenciaBotoesBarraPedido(true);
            }
        }

        private void btnPedidoSalvar_Click(object sender, EventArgs e)
        {
            salvarPedido();
            habilitaControlesPedido(false);
            limparControlesPedido();
            gerenciaBotoesBarraPedido(true);
            preencheGridPedido();
        }

        private void btnPedidoAlterar_Click(object sender, EventArgs e)
        {
            habilitaControlesPedido(true);
            gerenciaBotoesBarraPedido(false);
        }

        private void btnPedidoNovo_Click(object sender, EventArgs e)
        {
            habilitaControlesPedido(true);
            limparControlesPedido();
            gerenciaBotoesBarraPedido(false);
        }

        private void btnPedidoExcluir_Click(object sender, EventArgs e)
        {
            if (pedido.getPedidoId() != 0)
            {
                DialogResult retorno = MessageBox.Show("Deseja excluir o Pedido?", "Exclusão",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (retorno == DialogResult.Yes)
                {
                    excluiPedido();
                    limparControlesPedido();
                    preencheGridPedido();
                }
            }
            else
            {
                MessageBox.Show("Selecione o Pedido para Excluir!!", "Aviso!!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void grdPedido_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pedido.setPedidoId(Convert.ToInt32(grdPedido.Rows[grdPedido.CurrentRow.Index].Cells[0].Value.ToString()));
            preencheDadosControlePedido();
            preencheGridItemPedido();
        }

        private void btnItemPedidoNovo_Click(object sender, EventArgs e)
        {
            habilitaControlesItemPedido(true);
            limparControlesItemPedido();
            gerenciaBotoesBarraItemPedido(false);
        }

        private void btnItemPedidoAlterar_Click(object sender, EventArgs e)
        {
            habilitaControlesItemPedido(true);
            gerenciaBotoesBarraItemPedido(false);
        }

        private void btnItemPedidoExcluir_Click(object sender, EventArgs e)
        {
            grdItemPedido.Rows.RemoveAt(grdItemPedido.CurrentRow.Index);
        }

        private void btnItemPedidoSalvar_Click(object sender, EventArgs e)
        {
            DataGridViewRow item = new DataGridViewRow();
            item.CreateCells(grdItemPedido);
            item.Cells[0].Value = cboProduto.SelectedValue;
            item.Cells[1].Value = cboProduto.Text;
            item.Cells[2].Value = txtQtde.Text;
            item.Cells[3].Value = "10"; //Valor do produto
            item.Cells[4].Value = "40"; //valor do produto * quantidade
            grdItemPedido.Rows.Add(item);

            habilitaControlesItemPedido(false);
            limparControlesItemPedido();
            gerenciaBotoesBarraItemPedido(true);
        }

        private void btnItemPedidoCancelar_Click(object sender, EventArgs e)
        {
            habilitaControlesItemPedido(false);
            limparControlesItemPedido();
            gerenciaBotoesBarraItemPedido(true);
        }

        private void grdItemPedido_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cboProduto.SelectedValue = Convert.ToInt32(grdItemPedido.Rows[grdItemPedido.CurrentRow.Index].Cells[0].Value.ToString());
            txtQtde.Text = grdItemPedido.Rows[grdItemPedido.CurrentRow.Index].Cells[2].Value.ToString();
        }
    }
}
