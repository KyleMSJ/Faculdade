﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Pedidos_ItemPedidos
{
    public class csPedido
    {
        private Int32 pedidoId;
        private DateTime pedidoData;
        private Int32 clienteId;
        private Int32 funcionarioId;
        private double pedidoValor;
        private double pedidoDesconto;

        private conectMySql conexao = new conectMySql();

        public void setPedidoId(Int32 valor)
        {
            pedidoId = valor;
        }

        public Int32 getPedidoId()
        {
            return pedidoId;
        }

        public void setPedidoData(DateTime valor)
        {
            pedidoData = valor;
        }

        public DateTime getPedidoData()
        {
            return pedidoData;
        }

        public void setClienteId(Int32 valor)
        {
            clienteId = valor;
        }

        public Int32 getClienteId()
        {
            return clienteId;
        }

        public void setFuncionarioId(Int32 valor)
        {
            funcionarioId = valor;
        }

        public Int32 getFuncionarioId()
        {
            return funcionarioId;
        }

        public void setPedidoValor(double valor)
        {
            pedidoValor = valor;
        }

        public double getPedidoValor()
        {
            return pedidoValor;
        }

        public void setPedidoDesconto(double valor)
        {
            pedidoDesconto = valor;
        }

        public double getPedidoDesconto()
        {
            return pedidoDesconto;
        }

        public void inserir()
        {
            string sql = "INSERT INTO pedido(pedidodata, clienteid, funcionarioid, pedidovalor, pedidodesconto) ";
            sql += " VALUES (";
            sql += "'" + pedidoData.ToString("yyyy-MM-dd") + "', ";
            sql += clienteId + ", ";
            sql += funcionarioId + ", ";
            sql += pedidoValor.ToString() + ", ";
            sql += pedidoDesconto.ToString();
            sql += ")";
            conexao.executarSql(sql);
        }

        public void update()
        {
            string sql = "UPDATE pedido SET ";
            sql += "pedidodata = '" + pedidoData.ToString("yyyy-MM-dd") + "',";
            sql += "clienteid = " + clienteId.ToString() + ",";
            sql += "funcionarioid = " + funcionarioId.ToString() +",";
            sql += "pedidovalor = " + pedidoValor.ToString() + ",";
            sql += "pedidodesconto =  " + pedidoDesconto.ToString() +" ";
            sql += "WHERE pedidoid = " + pedidoId.ToString();
            conexao.executarSql(sql);
        }

        public void delete()
        {
            string sql = "DELETE FROM pedido WHERE pedidoid = " + pedidoId.ToString();
            conexao.executarSql(sql);
        }

        public DataTable select()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable tabela = new DataTable();
            string sql = "SELECT pedidoid, pedidodata, clientenome ";
            sql += "FROM pedido ";
            sql += "INNER JOIN cliente on pedido.clienteid = cliente.clienteid";
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(tabela);
            return tabela;
        }

        public void selectPedido()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataset = new DataSet();
            string sql = "SELECT pedidoid, pedidodata, clienteid, funcionarioid, pedidovalor, pedidodesconto FROM pedido WHERE pedidoid = " + pedidoId.ToString();
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataset);

            pedidoId = Convert.ToInt32(dataset.Tables[0].Rows[0][0].ToString());
            pedidoData = Convert.ToDateTime(dataset.Tables[0].Rows[0][1].ToString());
            clienteId = Convert.ToInt32(dataset.Tables[0].Rows[0][2].ToString());
            funcionarioId = Convert.ToInt32(dataset.Tables[0].Rows[0][3].ToString());
            pedidoValor = Convert.ToDouble(dataset.Tables[0].Rows[0][4].ToString());
            pedidoDesconto = Convert.ToDouble(dataset.Tables[0].Rows[0][5].ToString());
        }

        public void selectPedidoUltimo()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataSet dataset = new DataSet();
            string sql = "SELECT max(pedidoid) FROM pedido"; 
            adapter = conexao.executaRetornaDados(sql);
            adapter.Fill(dataset);

            pedidoId = Convert.ToInt32(dataset.Tables[0].Rows[0][0].ToString());
        }

    }
}
