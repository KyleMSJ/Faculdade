﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto1
{
    public partial class frmPrincipal : Form // ':' significa "herança"
    {
        private string operacao;
        private double valor;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValor.Text = "";
            operacao = "";
            valor = 0.0;
        }

        private void btnUm_Click(object sender, EventArgs e)
        {
            //txtValor.Text = txtValor.Text + "1"; 
            txtValor.Text += "1";
        }

        private void btnDois_Click(object sender, EventArgs e)
        {
            txtValor.Text += "2";
        }

        private void btnTres_Click(object sender, EventArgs e)
        {
            txtValor.Text += "3";
        }

        private void btnQuatro_Click(object sender, EventArgs e)
        {
            txtValor.Text += "4";
        }

        private void btnCinco_Click(object sender, EventArgs e)
        {
            txtValor.Text += "5";
        }

        private void btnSeis_Click(object sender, EventArgs e)
        {
            txtValor.Text += "6";
        }

        private void btnSete_Click(object sender, EventArgs e)
        {
            txtValor.Text += "7";
        }

        private void btnOito_Click(object sender, EventArgs e)
        {
            txtValor.Text += "8";
        }

        private void btnNove_Click(object sender, EventArgs e)
        {
            txtValor.Text += "9";
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            txtValor.Text += "0";
        }

        private void btnVirgula_Click(object sender, EventArgs e)
        {
            if (txtValor.Text.Contains(","))
            {
                
            }
            else
            {
                if(txtValor.Text == "")
                {
                    txtValor.Text += "0,";
                }
                else
                {
                    txtValor.Text += ",";
                }
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            operacao = "/";
            valor = Convert.ToDouble (txtValor.Text);
            txtValor.Text = "";
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            operacao = "*";
            valor = Convert.ToDouble(txtValor.Text);
            txtValor.Text = "";
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            operacao = "-";
            valor = Convert.ToDouble(txtValor.Text);
            txtValor.Text = "";
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            operacao = "+";
            valor = Convert.ToDouble(txtValor.Text);
            txtValor.Text = "";
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            switch (operacao)
            {
                case "+":
                    txtValor.Text = (valor + Convert.ToDouble(txtValor.Text)).ToString();
                    operacao = "";
                    valor = 0.0;
                    break;
                case "-":
                    txtValor.Text = (valor - Convert.ToDouble(txtValor.Text)).ToString();
                    operacao = "";
                    valor = 0.0;
                    break;
                case "*":
                    txtValor.Text = (valor * Convert.ToDouble(txtValor.Text)).ToString();
                    operacao = "";
                    valor = 0.0;
                    break;
                case "/":
                    if (txtValor.Text == "0" || txtValor.Text == "")
                    {
                        //Mensagem de divisão por 0 para o usuário
                        MessageBox.Show("Não é possível divisão por zero!");
                    }
                    else
                    {
                        txtValor.Text = (valor / Convert.ToDouble(txtValor.Text)).ToString();
                        operacao = "";
                        valor = 0.0;
                    }
                    break;
                case "x²":
                    txtValor.Text = Convert.ToDouble(Math.Pow(valor, 2)).ToString();
                    operacao = "";
                    valor = 0.0;
                    break;
                case "√x":
                    txtValor.Text = Convert.ToDouble(Math.Sqrt(valor)).ToString();
                    operacao = "";
                    valor = 0.0;
                    break;
                default:
                    break;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtValor.Text = txtValor.Text.Substring(0, txtValor.Text.Length - 1);
        }

        private void btnSqr_Click(object sender, EventArgs e)
        {
            operacao = "x²";
            valor = Convert.ToDouble(txtValor.Text);
            txtValor.Text = ""; 
        }

        private void btnRoot_Click(object sender, EventArgs e)
        {
            operacao = "√x";
            valor = Convert.ToDouble(txtValor.Text);
            txtValor.Text = "";
        }
    }
}
