Página criada conforme orientações da aula do dia 03/08, com auxílio dos materiais de aula presentes no teams e utilizando media queries.

Críticas / sugestões / correções para melhoria são bem-vindas! 

Caio Marcelo da Silva de Jesus
PC3011259