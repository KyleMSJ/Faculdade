public class CPrincipal {
	
	public static void main (String[] args)
	{
		// TODO Auto-Generated method stub
		
		System.out.println("Hello World. \n\n");
		
		int v1;
		int v2;
		int result;
		
		v1 = 2;
		v2 = 5;
	    result = v1 + v2;
		
	    long x = 1;
	    
		float v3 = 20;
		float v4 = 22;
		float resultado;
	
		
		resultado = v3 % v4;
		
		if (!(resultado>10))
		{
			System.out.println(" 1 \n\n ");
		}
		else if (resultado > 30) 
		{
			System.out.println(" 2 \n\n ");
		}
		else {
			System.out.println(" 3 \n\n ");
		}
				
		String nome = "Caio Marcelo";
		
		result = (int)(v3+v4);
		
		System.out.println("O resultado da soma de v3 + v4 �: " + result);
	}
}