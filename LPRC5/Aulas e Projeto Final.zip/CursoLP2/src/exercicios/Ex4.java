package exercicios;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Ex4 {

	/*Construa um programa que leia a nome (N), quantidade (Q) e o pre�o (PR) de v�rios produtos 
	diferentes, comprados por uma empresa, e apresente o total gasto por ela e o 
	valor unit�rio de cada produto. O final da lista de produtos dever� ser indicado 
pelo usu�rio (escolha a maneira que preferir).*/
	
	public static void main (String[] args)
	{
		List<String> nomes = new ArrayList<String>();
        List<Integer> quantidades = new ArrayList<Integer>();
        List<Float> precos = new ArrayList<Float>();
        ArrayList<Float> totais = new ArrayList<Float>();
        
        String nome = "";
        int qtd = 0;
        float preco = 0;
        int opt = 0;
        float totalUni = 0; 
		float total = 0;
		
		do
		{
		nome = JOptionPane.showInputDialog("Digite o nome do produto: ");
		nomes.add(nome);
		preco = Float.valueOf(JOptionPane.showInputDialog("Digite o pre�o do produto: ")).floatValue();
		precos.add(preco);
		qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade: "));
		quantidades.add(qtd);
		
		totalUni = preco * qtd;
		totais.add(totalUni);
		total += totalUni;
		
		opt = Integer.parseInt(JOptionPane.showInputDialog("Deseja Continuar? \n 1 - Sim \n 2 - N�o"));
		
		} while (opt != 2);
		
		System.out.println("Produtos \t   Valor Unitario \t Quantidade \t\t Total");
		for (int i = 0; i < nomes.size(); i++)
		{
		System.out.println(nomes.get(i) + "\t\t\t" + precos.get(i) + "\t\t\t" + quantidades.get(i));			
		}
		System.out.println("\t\t\t\t\t\t\t\t R$ " + String.format("%.02f", total));	
			
		
	}
	
		
	
		
}

