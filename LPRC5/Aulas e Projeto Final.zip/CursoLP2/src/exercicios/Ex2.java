package exercicios;

import java.util.Locale;
import javax.swing.JOptionPane;

	public class Ex2 {

		/*
		 * Fa�a um programa que receba dois n�meros e execute as opera��es listadas a
		 * seguir de acordo com a escolha do usu�rio. Se a op��o digitada for inv�lida
		 * (n�o � a op��o 1 nem a 2), mostrar uma mensagem de erro e terminar o
		 * programa. Lembre-se de que na opera��o 2 o segundo n�mero deve ser diferente
		 * de zero.
		 */
	    public static void main(String[] args)
	    {
	        Locale.setDefault(new Locale("pt", "BR"));
	        int opt = 0;
	        float num1 = 0;
	        float num2 = 0;


	        num1 = Float.valueOf(JOptionPane.showInputDialog("Digite um n�mero: ")).floatValue();
	        num2 = Float.valueOf(JOptionPane.showInputDialog("Digite outro n�mero: ")).floatValue();


	        opt = Integer.parseInt(JOptionPane.showInputDialog("Selecione a Opera��o: "
	        		+ "\n 1 - Multiplica��o \n 2 - Divis�o"));
		       
	        if(opt == 2 && num2 == 0) {

	        	JOptionPane.showMessageDialog(null, "Divis�o por 0 n�o � permitida!", "Aviso", JOptionPane.WARNING_MESSAGE);
	        }
	        else {
	            switch(opt){

	                case 1:
	                	JOptionPane.showMessageDialog(null, "A multiplica��o � igual a: " + String.format("%.02f", num1 * num2), 
	                			"Resultado", JOptionPane.INFORMATION_MESSAGE);
	                    break;
	                case 2:
	                	JOptionPane.showMessageDialog(null, "A divis�o � igual a: " + String.format("%.02f", num1 / num2),
	                			"Resultado", JOptionPane.INFORMATION_MESSAGE);
	                    break;

	                default:
	                    JOptionPane.showMessageDialog(null, "ERRO! op��o inv�lida, encerrando o programa...");
	                    System.exit(0);
	            }
	            }

	    }
	}
