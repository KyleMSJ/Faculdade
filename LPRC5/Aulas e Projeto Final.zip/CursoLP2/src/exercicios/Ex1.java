package exercicios;

import javax.swing.JOptionPane; // caixas de di�logo
import java.lang.String;

public class Ex1 {

	/*
	 * Um estabelecimento comercial possui margem de lucro de acordo com o valor do
	 * produto.
	 * 
	 * Fa�a um programa que leia o valor de custo do um produto e mostre na tela o
	 * valor do lucro da loja e qual o valor do produto com o lucro
	 */
	
	public static void main(String[] args) {

		float custo = 0;
		float vFinal = 0;
		float lucro = 0;
		
				// convers�o de uma string pra double
		custo = Float.valueOf(JOptionPane.showInputDialog("digite o valor do produto: ")).floatValue(); 
		
		if (custo <= 50.00) {
			vFinal = (float) (custo * 1.10);
			lucro = vFinal - custo;
		} else if (custo > 50.00 && custo <= 100.00) {
			vFinal = (float) (custo * 1.18);
			lucro = vFinal - custo;
		} else {
			vFinal = (float) (custo * 1.30);
			lucro = vFinal - custo;	
		}
		
		JOptionPane.showMessageDialog(null, "Valor final do produto � = R$" + String.format("%.02f", vFinal)
				+ " \ne o valor do lucro = R$" + String.format("%.02f", lucro), "Informa��o",
				JOptionPane.INFORMATION_MESSAGE);
	}
}
