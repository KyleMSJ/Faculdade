package exercicios;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Ex3 {

    public static void main(String[] args)
    {
        ArrayList<Integer> idades = new ArrayList<Integer>();
        ArrayList<String> opinioes = new ArrayList<String>();
        
        String idade = "";
        String opiniao = "";
        int somaIdades = 0;
        int idadesInt = 0;
        int rA = 0;
        int rB = 0;
        int rC = 0;
        int rD = 0;
        int rE = 0;
        int erro = 0;
		do {
			idade = JOptionPane.showInputDialog("Digite sua idade:" );
        	idadesInt = Integer.parseInt(idade);
        	idades.add(idadesInt);
        	
           	if (Integer.parseInt(idade) >=0) {
        	opiniao = JOptionPane.showInputDialog("Digite sua opini�o sobre o filme: \nA ---- �timo"
        			+ "\nB ---- Bom \nC ---- Regular \nD ---- Ruim \nE ---- P�ssimo");
        	opiniao = opiniao.toLowerCase();
        	opinioes.add(opiniao);
        	switch (opiniao) {
        	case "a":
        		rA++;
        		break;
        	case "b":
        		rB++;
        		break;
        	case "c":
        		rC++;
        		break;
        	case "d":
        		rD++;
        		break;
        	case "e":
        		rE++;
        		break;
        	default:
        		JOptionPane.showMessageDialog(null, "Erro! Digite uma op��o v�lida!", "Alerta!", 
        				JOptionPane.WARNING_MESSAGE);
        	}
        	somaIdades += idadesInt; // Somador de idades ou contador 
        	}
        	
        }while (idadesInt >= 0);
            

        JOptionPane.showMessageDialog(null, "Quantidade de pessoas: " + (idades.size() -1), "Informa��o", 
        		JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "A m�dia das idades �: " + (somaIdades/(idades.size() -1)), "Informa��o", 
        		JOptionPane.INFORMATION_MESSAGE);
        
        float total_idades = idades.size()-1;
        float porcRespA = (rA/total_idades)*100;
        
        JOptionPane.showMessageDialog(null, "Porcentgem de respostas A: " + String.format("%.00f", porcRespA) + 
        		"%", opiniao, JOptionPane.INFORMATION_MESSAGE);
        
        float porcRespB = (rB/total_idades)*100;
        JOptionPane.showMessageDialog(null, "Porcentgem de respostas B: " + String.format("%.00f", porcRespB) + 
        		"%", opiniao, JOptionPane.INFORMATION_MESSAGE);
        
        float porcRespC = (rC/total_idades)*100;
        JOptionPane.showMessageDialog(null, "Porcentgem de respostas C: " + String.format("%.00f", porcRespC) + 
        		"%", opiniao, JOptionPane.INFORMATION_MESSAGE);
        
        float porcRespD = (rD/total_idades)*100;
        JOptionPane.showMessageDialog(null, "Porcentgem de respostas D: " + String.format("%.00f", porcRespD) + 
        		"%", opiniao, JOptionPane.INFORMATION_MESSAGE);
        
        float porcRespE = (rE/total_idades)*100;
        JOptionPane.showMessageDialog(null, "Porcentgem de respostas E: " + String.format("%.00f", porcRespE) + 
        		"%", opiniao, JOptionPane.INFORMATION_MESSAGE);
    }

}