﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Npgsql;

namespace EscolaTecnica
{
    class ConexaoPostgreSQL
    {
        public NpgsqlConnection conn;

        private static string Host = "localhost";
        private static string User = "postgres";
        private static string DBname = "db_test";
        private static string Password = "postgres";
        private static string Port = "5432";


        private void conectaPostgreSQL()
        {
            try
            {
                string connString =
                String.Format(
                    "Server={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
                    Host,
                    User,
                    DBname,
                    Port,
                    Password);
                this.conn = new NpgsqlConnection(connString);
                conn.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString());
            }
        }

        private void desconectaPostgreSQL(NpgsqlConnection conn)
        {
            conn.Close();
        }
    }
}
