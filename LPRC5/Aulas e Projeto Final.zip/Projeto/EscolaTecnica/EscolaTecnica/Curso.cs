﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Data;
using System.Globalization;

namespace EscolaTecnica
{
    public class csCurso
    {
        public Int32 nro_C;
        public string nome_C;
        public Int32 Prof_C;
        public Int32 AT_C;
        public DateTime dataIni;
        public DateTime dataEnd;


        private ConexaoPostgreSQL connectC = new ConexaoPostgreSQL();

        public void setCursoNro(Int32 valor)
        {
            nro_C = valor;
        }

        public Int32 getCursoNro()
        {
            return nro_C;
        }

        public void setCursoNome(string valor)
        {
            nome_C = valor;
        }

        public string getCursoNome()
        {
            return nome_C;
        }

        public void setProfResp(Int32 valor)
        {
            Prof_C = valor;
        }

        public Int32 getProfResp()
        {
            return Prof_C;
        }

        public void setATec_C(Int32 valor)
        {
            AT_C = valor;
        }

        public Int32 getATec_C()
        {
            return AT_C;
        }
        public void setDataIni(DateTime valor)
        {
            dataIni = valor;
        }

        public DateTime getDataIni()
        {
            return dataIni;
        }

        public void setDataEnd(DateTime valor)
        {
            dataEnd = valor;
        }

        public DateTime getDataEnd()
        {
            return dataEnd;
        }

         public void inserir()
         {
            string sql = "INSERT INTO tb.curso(id_curso, nome_curso, d_inicio," +
                " d_fim, id_professor, id_area) VALUES(" + nro_C.ToString() + ", " +
                "'" + nome_C + "', '"
                + dataIni.ToString("yyyy-MM-dd") + "', '" + dataEnd.ToString("yyyy-MM-dd") +
                "', " + Prof_C.ToString() + ", " + AT_C.ToString() + ")";
            connectC.executarSql(sql);
        }

        public void update()
        {
            string sql = "UPDATE tb.curso SET nome_curso = '" + nome_C + "', " +
                "d_inicio = '" + dataIni.ToString("yyyy-MM-dd") +
                "', d_fim = " + dataEnd.ToString("yyyy-MM-dd") + ", " +
                "id_professor = " + Prof_C.ToString() + " " +
                "id_area = " + AT_C.ToString() +
               " WHERE id_curso = " + nro_C + ";";
             connectC.executarSql(sql);
        }
         public void delete()
         {
            string sql = "DELETE FROM tb.curso WHERE id_curso = " + nro_C;
            connectC.executarSql(sql);
         }

         public DataTable select()
         {
             NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
             DataTable tabela = new DataTable();
             string sql = "SELECT id_curso, nome_curso, id_area FROM tb.curso";
             adapter = connectC.executaRetornaDados(sql.ToString());
             adapter.Fill(tabela);
             return tabela;
         }

         public void selectCurso() 
         {
             NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
             DataSet dataset = new DataSet();
             string sql = "SELECT * FROM tb.curso WHERE id_curso = " + nro_C.ToString();
             adapter = connectC.executaRetornaDados(sql);
             adapter.Fill(dataset);

            nro_C = Convert.ToInt32(dataset.Tables[0].Rows[0][0].ToString());
            nome_C = dataset.Tables[0].Rows[0][1].ToString();
            Prof_C = Convert.ToInt32(dataset.Tables[0].Rows[0][2].ToString()); 
            dataIni = Convert.ToDateTime(dataset.Tables[0].Rows[0][3].ToString());
            dataEnd = Convert.ToDateTime(dataset.Tables[0].Rows[0][4].ToString());
            AT_C = Convert.ToInt32(dataset.Tables[0].Rows[0][5].ToString());
        }

    }
}
