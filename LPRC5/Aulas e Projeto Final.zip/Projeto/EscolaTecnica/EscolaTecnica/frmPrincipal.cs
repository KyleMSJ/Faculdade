﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaTecnica
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        /*private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sobre fSobre = new Sobre();
            fSobre.MdiParent = this;
            fSobre.Show();
        }*/


        private void professorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastroProfessor fprof = new CadastroProfessor();
            fprof.MdiParent = this;
            fprof.Show();
        }

        private void cursoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastroCursos fcurso = new CadastroCursos();
            fcurso.MdiParent = this;
            fcurso.Show();
        }

        private void áreaTécnicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CadastroAreaTecnica fAT = new CadastroAreaTecnica();
            fAT.MdiParent = this;
            fAT.Show();
        }

        /*private void ConsultaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsulta consulta = new frmConsulta();
            consulta.MdiParent = this;
            consulta.Show();
        } Linhas 74 - 77 do frmPrincipal.Designer.cs */
    }
}
