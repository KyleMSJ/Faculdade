﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using Npgsql;

namespace EscolaTecnica
{
    class ConexaoPostgreSQL

    {
        public static string Host = "localhost";
        public static string User = "postgres";
        public static string DBname = "escolatecnica";
        public static string Password = "75rd962a";
        public static string Port = "5432";

        public NpgsqlConnection conn;

        string connString =
                String.Format("Server={0};Username={1};Database={2};Port={3};Password={4};" +
                "SSLMode=Prefer",
                Host,
                User,
                DBname,
                Port,
                Password);

       // string connectionString = "";
        /*private void dadosConexao()
        {
            string caminho = @"A:\IFSP\5º Período\Linguagem de Programação 2\Projeto\acesso.txt";

            if (File.Exists(caminho))
            {
                StreamReader arquivo = new StreamReader(caminho);
                connectionString = arquivo.ReadLine().ToString();   
            }
        }*/

        private void conectaPostgreSQL()
        {
            try
            {
                conn = new NpgsqlConnection(connString);
                conn.Open();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString());
            }
        }

        private void desconectaPostgreSQL(NpgsqlConnection conn)
        {
            conn.Close();
        }

        public NpgsqlDataAdapter executaRetornaDados(string sql)
        {
            conectaPostgreSQL();
            NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(sql, conn);
            return adapter;
        }

        public void executarSql (string sql)
        {
            conectaPostgreSQL();
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);
            command.ExecuteNonQuery();
        }
    }
}
