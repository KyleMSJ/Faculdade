﻿
namespace EscolaTecnica
{
    partial class CadastroAreaTecnica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroAreaTecnica));
            this.txtDescricao_AT = new System.Windows.Forms.TextBox();
            this.txtCod_AT = new System.Windows.Forms.TextBox();
            this.txtQtd_AT = new System.Windows.Forms.TextBox();
            this.lblQtd_AT = new System.Windows.Forms.Label();
            this.lblDescricaoAT = new System.Windows.Forms.Label();
            this.lblCod_AT = new System.Windows.Forms.Label();
            this.grdDadosAreaTecnica = new System.Windows.Forms.DataGridView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnEditar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.notificationEventHandlerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosAreaTecnica)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.notificationEventHandlerBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDescricao_AT
            // 
            this.txtDescricao_AT.Location = new System.Drawing.Point(612, 206);
            this.txtDescricao_AT.Margin = new System.Windows.Forms.Padding(5);
            this.txtDescricao_AT.Multiline = true;
            this.txtDescricao_AT.Name = "txtDescricao_AT";
            this.txtDescricao_AT.Size = new System.Drawing.Size(339, 293);
            this.txtDescricao_AT.TabIndex = 63;
            // 
            // txtCod_AT
            // 
            this.txtCod_AT.Location = new System.Drawing.Point(616, 94);
            this.txtCod_AT.Margin = new System.Windows.Forms.Padding(5);
            this.txtCod_AT.Name = "txtCod_AT";
            this.txtCod_AT.Size = new System.Drawing.Size(58, 26);
            this.txtCod_AT.TabIndex = 62;
            // 
            // txtQtd_AT
            // 
            this.txtQtd_AT.Location = new System.Drawing.Point(612, 150);
            this.txtQtd_AT.Margin = new System.Windows.Forms.Padding(5);
            this.txtQtd_AT.Name = "txtQtd_AT";
            this.txtQtd_AT.Size = new System.Drawing.Size(97, 26);
            this.txtQtd_AT.TabIndex = 61;
            // 
            // lblQtd_AT
            // 
            this.lblQtd_AT.AutoSize = true;
            this.lblQtd_AT.Location = new System.Drawing.Point(612, 125);
            this.lblQtd_AT.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblQtd_AT.Name = "lblQtd_AT";
            this.lblQtd_AT.Size = new System.Drawing.Size(101, 20);
            this.lblQtd_AT.TabIndex = 60;
            this.lblQtd_AT.Text = "nº de cursos ";
            // 
            // lblDescricaoAT
            // 
            this.lblDescricaoAT.AutoSize = true;
            this.lblDescricaoAT.Location = new System.Drawing.Point(612, 181);
            this.lblDescricaoAT.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDescricaoAT.Name = "lblDescricaoAT";
            this.lblDescricaoAT.Size = new System.Drawing.Size(80, 20);
            this.lblDescricaoAT.TabIndex = 59;
            this.lblDescricaoAT.Text = "Descrição";
            // 
            // lblCod_AT
            // 
            this.lblCod_AT.AutoSize = true;
            this.lblCod_AT.Location = new System.Drawing.Point(612, 69);
            this.lblCod_AT.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCod_AT.Name = "lblCod_AT";
            this.lblCod_AT.Size = new System.Drawing.Size(59, 20);
            this.lblCod_AT.TabIndex = 58;
            this.lblCod_AT.Text = "Código";
            // 
            // grdDadosAreaTecnica
            // 
            this.grdDadosAreaTecnica.AllowUserToAddRows = false;
            this.grdDadosAreaTecnica.AllowUserToDeleteRows = false;
            this.grdDadosAreaTecnica.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDadosAreaTecnica.Location = new System.Drawing.Point(18, 69);
            this.grdDadosAreaTecnica.Margin = new System.Windows.Forms.Padding(9, 12, 9, 12);
            this.grdDadosAreaTecnica.Name = "grdDadosAreaTecnica";
            this.grdDadosAreaTecnica.ReadOnly = true;
            this.grdDadosAreaTecnica.Size = new System.Drawing.Size(580, 430);
            this.grdDadosAreaTecnica.TabIndex = 57;
            this.grdDadosAreaTecnica.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdDadosAreaTecnica_CellClick);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNovo,
            this.btnEditar,
            this.btnCancelar,
            this.btnSalvar,
            this.btnExcluir,
            this.btnSair});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.MaximumSize = new System.Drawing.Size(2700, 365);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStrip1.Size = new System.Drawing.Size(960, 57);
            this.toolStrip1.TabIndex = 56;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnNovo
            // 
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(54, 54);
            this.btnNovo.Text = "toolStripButton1";
            this.btnNovo.ToolTipText = "Cadastra novo pedido";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnEditar.Image = ((System.Drawing.Image)(resources.GetObject("btnEditar.Image")));
            this.btnEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(54, 54);
            this.btnEditar.Text = "toolStripButton2";
            this.btnEditar.ToolTipText = "Edita dados do pedido";
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(54, 54);
            this.btnCancelar.Text = "toolStripButton3";
            this.btnCancelar.ToolTipText = "Cancelar cadastro";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(54, 54);
            this.btnSalvar.Text = "toolStripButton4";
            this.btnSalvar.ToolTipText = "Salvar pedido";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(54, 54);
            this.btnExcluir.Text = "toolStripButton5";
            this.btnExcluir.ToolTipText = "Excluir pedido";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(54, 54);
            this.btnSair.Text = "toolStripButton6";
            this.btnSair.ToolTipText = "Sair do cadastro";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // notificationEventHandlerBindingSource
            // 
            this.notificationEventHandlerBindingSource.DataSource = typeof(Npgsql.NotificationEventHandler);
            // 
            // CadastroAreaTecnica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 515);
            this.Controls.Add(this.txtDescricao_AT);
            this.Controls.Add(this.txtCod_AT);
            this.Controls.Add(this.txtQtd_AT);
            this.Controls.Add(this.lblQtd_AT);
            this.Controls.Add(this.lblDescricaoAT);
            this.Controls.Add(this.lblCod_AT);
            this.Controls.Add(this.grdDadosAreaTecnica);
            this.Controls.Add(this.toolStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "CadastroAreaTecnica";
            this.Text = "Cadastro da Área Técnica";
            this.Load += new System.EventHandler(this.CadastroAreaTecnica_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosAreaTecnica)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.notificationEventHandlerBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDescricao_AT;
        private System.Windows.Forms.TextBox txtCod_AT;
        private System.Windows.Forms.TextBox txtQtd_AT;
        private System.Windows.Forms.Label lblQtd_AT;
        private System.Windows.Forms.Label lblDescricaoAT;
        private System.Windows.Forms.Label lblCod_AT;
        private System.Windows.Forms.DataGridView grdDadosAreaTecnica;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnEditar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.BindingSource notificationEventHandlerBindingSource;
    }
}