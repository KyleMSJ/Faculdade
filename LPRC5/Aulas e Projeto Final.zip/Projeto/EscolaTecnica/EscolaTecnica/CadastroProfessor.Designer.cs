﻿
namespace EscolaTecnica
{
    partial class CadastroProfessor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroProfessor));
            this.grdDadosProfessor = new System.Windows.Forms.DataGridView();
            this.txtBirthDate_P = new System.Windows.Forms.MaskedTextBox();
            this.txtCursos_P = new System.Windows.Forms.TextBox();
            this.txtCode_P = new System.Windows.Forms.TextBox();
            this.lblCursos_P = new System.Windows.Forms.Label();
            this.lblBirthDate_P = new System.Windows.Forms.Label();
            this.lblCode_P = new System.Windows.Forms.Label();
            this.lblNomeP = new System.Windows.Forms.Label();
            this.txtNomeP = new System.Windows.Forms.TextBox();
            this.lblSalario_P = new System.Windows.Forms.Label();
            this.txtSalario_P = new System.Windows.Forms.TextBox();
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnEditar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosProfessor)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grdDadosProfessor
            // 
            this.grdDadosProfessor.AllowUserToAddRows = false;
            this.grdDadosProfessor.AllowUserToDeleteRows = false;
            this.grdDadosProfessor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDadosProfessor.Location = new System.Drawing.Point(13, 76);
            this.grdDadosProfessor.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grdDadosProfessor.Name = "grdDadosProfessor";
            this.grdDadosProfessor.ReadOnly = true;
            this.grdDadosProfessor.Size = new System.Drawing.Size(480, 409);
            this.grdDadosProfessor.TabIndex = 15;
            this.grdDadosProfessor.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdDados_CellClick);
            // 
            // txtBirthDate_P
            // 
            this.txtBirthDate_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBirthDate_P.Location = new System.Drawing.Point(677, 244);
            this.txtBirthDate_P.Mask = "00/00/0000";
            this.txtBirthDate_P.Name = "txtBirthDate_P";
            this.txtBirthDate_P.Size = new System.Drawing.Size(69, 22);
            this.txtBirthDate_P.TabIndex = 38;
            this.txtBirthDate_P.ValidatingType = typeof(System.DateTime);
            // 
            // txtCursos_P
            // 
            this.txtCursos_P.Location = new System.Drawing.Point(660, 205);
            this.txtCursos_P.Name = "txtCursos_P";
            this.txtCursos_P.Size = new System.Drawing.Size(46, 20);
            this.txtCursos_P.TabIndex = 37;
            // 
            // txtCode_P
            // 
            this.txtCode_P.Location = new System.Drawing.Point(518, 102);
            this.txtCode_P.Name = "txtCode_P";
            this.txtCode_P.Size = new System.Drawing.Size(81, 20);
            this.txtCode_P.TabIndex = 36;
            // 
            // lblCursos_P
            // 
            this.lblCursos_P.AutoSize = true;
            this.lblCursos_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCursos_P.Location = new System.Drawing.Point(514, 203);
            this.lblCursos_P.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCursos_P.Name = "lblCursos_P";
            this.lblCursos_P.Size = new System.Drawing.Size(148, 20);
            this.lblCursos_P.TabIndex = 35;
            this.lblCursos_P.Text = "Cursos Ministrados:";
            // 
            // lblBirthDate_P
            // 
            this.lblBirthDate_P.AutoSize = true;
            this.lblBirthDate_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBirthDate_P.Location = new System.Drawing.Point(512, 244);
            this.lblBirthDate_P.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBirthDate_P.Name = "lblBirthDate_P";
            this.lblBirthDate_P.Size = new System.Drawing.Size(158, 20);
            this.lblBirthDate_P.TabIndex = 34;
            this.lblBirthDate_P.Text = "Data de Nascimento:";
            // 
            // lblCode_P
            // 
            this.lblCode_P.AutoSize = true;
            this.lblCode_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCode_P.Location = new System.Drawing.Point(514, 79);
            this.lblCode_P.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCode_P.Name = "lblCode_P";
            this.lblCode_P.Size = new System.Drawing.Size(132, 20);
            this.lblCode_P.TabIndex = 33;
            this.lblCode_P.Text = "Código Funcional";
            // 
            // lblNomeP
            // 
            this.lblNomeP.AutoSize = true;
            this.lblNomeP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeP.Location = new System.Drawing.Point(514, 139);
            this.lblNomeP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeP.Name = "lblNomeP";
            this.lblNomeP.Size = new System.Drawing.Size(51, 20);
            this.lblNomeP.TabIndex = 32;
            this.lblNomeP.Text = "Nome";
            // 
            // txtNomeP
            // 
            this.txtNomeP.Location = new System.Drawing.Point(518, 162);
            this.txtNomeP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNomeP.Name = "txtNomeP";
            this.txtNomeP.Size = new System.Drawing.Size(216, 20);
            this.txtNomeP.TabIndex = 31;
            // 
            // lblSalario_P
            // 
            this.lblSalario_P.AutoSize = true;
            this.lblSalario_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario_P.Location = new System.Drawing.Point(514, 295);
            this.lblSalario_P.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario_P.Name = "lblSalario_P";
            this.lblSalario_P.Size = new System.Drawing.Size(58, 20);
            this.lblSalario_P.TabIndex = 39;
            this.lblSalario_P.Text = "Salário";
            // 
            // txtSalario_P
            // 
            this.txtSalario_P.Location = new System.Drawing.Point(518, 318);
            this.txtSalario_P.Name = "txtSalario_P";
            this.txtSalario_P.Size = new System.Drawing.Size(83, 20);
            this.txtSalario_P.TabIndex = 40;
            // 
            // btnNovo
            // 
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(54, 54);
            this.btnNovo.ToolTipText = "Cadastra novo cliente";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnEditar.Image = ((System.Drawing.Image)(resources.GetObject("btnEditar.Image")));
            this.btnEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(54, 54);
            this.btnEditar.Text = "toolStripButton2";
            this.btnEditar.ToolTipText = "Edita dados do cliente";
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(54, 54);
            this.btnCancelar.Text = "toolStripButton3";
            this.btnCancelar.ToolTipText = "Cancelar cadastro";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(54, 54);
            this.btnSalvar.Text = "toolStripButton4";
            this.btnSalvar.ToolTipText = "Salvar dados do cliente";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(54, 54);
            this.btnExcluir.Text = "toolStripButton5";
            this.btnExcluir.ToolTipText = "Excluir dados do cliente";
            this.btnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(54, 54);
            this.btnSair.Text = "toolStripButton6";
            this.btnSair.ToolTipText = "Sair do cadastro";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNovo,
            this.btnEditar,
            this.btnCancelar,
            this.btnSalvar,
            this.btnExcluir,
            this.btnSair});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.MaximumSize = new System.Drawing.Size(1200, 154);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip2.Size = new System.Drawing.Size(871, 57);
            this.toolStrip2.TabIndex = 13;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // CadastroProfessor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 513);
            this.Controls.Add(this.txtSalario_P);
            this.Controls.Add(this.lblSalario_P);
            this.Controls.Add(this.txtBirthDate_P);
            this.Controls.Add(this.txtCursos_P);
            this.Controls.Add(this.txtCode_P);
            this.Controls.Add(this.lblCursos_P);
            this.Controls.Add(this.lblBirthDate_P);
            this.Controls.Add(this.lblCode_P);
            this.Controls.Add(this.lblNomeP);
            this.Controls.Add(this.txtNomeP);
            this.Controls.Add(this.grdDadosProfessor);
            this.Controls.Add(this.toolStrip2);
            this.Name = "CadastroProfessor";
            this.Text = "Cadastro de Professores";
            this.Load += new System.EventHandler(this.CadastroProfessor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosProfessor)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView grdDadosProfessor;
        private System.Windows.Forms.MaskedTextBox txtBirthDate_P;
        private System.Windows.Forms.TextBox txtCursos_P;
        private System.Windows.Forms.TextBox txtCode_P;
        private System.Windows.Forms.Label lblCursos_P;
        private System.Windows.Forms.Label lblBirthDate_P;
        private System.Windows.Forms.Label lblCode_P;
        private System.Windows.Forms.Label lblNomeP;
        private System.Windows.Forms.TextBox txtNomeP;
        private System.Windows.Forms.Label lblSalario_P;
        private System.Windows.Forms.TextBox txtSalario_P;
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnEditar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.ToolStrip toolStrip2;
    }
}