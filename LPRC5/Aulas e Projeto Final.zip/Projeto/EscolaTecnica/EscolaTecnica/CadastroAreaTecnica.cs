﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


namespace EscolaTecnica
{
    public partial class CadastroAreaTecnica : Form
    {
        csAreaTecnica AT = new csAreaTecnica();

        bool newAreaTec = false;
        public CadastroAreaTecnica()
        {
            InitializeComponent();
        }

         private ConexaoPostgreSQL conexao = new ConexaoPostgreSQL();

        private void habilitaControlesAreaTecnica(bool status)
        {
            txtCod_AT.Enabled = status;
            txtDescricao_AT.Enabled = status;
            txtQtd_AT.Enabled = status;
        }

        private void limparControles()
        { 
            txtCod_AT.Text = "";
            txtDescricao_AT.Text = "";
            txtQtd_AT.Text = "";
        }

        private void gerenciaBotoesBarra(bool status)
        {
            btnNovo.Enabled = status;
            btnEditar.Enabled = status;
            btnExcluir.Enabled = status;
            btnSair.Enabled = status;
            btnSalvar.Enabled = !status;
            btnCancelar.Enabled = !status;
        }

        private void formataGridAreaTecnica()
        {
            grdDadosAreaTecnica.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdDadosAreaTecnica.Columns[0].HeaderText = "Código";
            grdDadosAreaTecnica.Columns[1].HeaderText = "Descricao";
            grdDadosAreaTecnica.Columns[2].HeaderText = "Quantidade de Cursos";

            grdDadosAreaTecnica.Columns[0].Width = 75;
            grdDadosAreaTecnica.Columns[1].Width = 350;
            grdDadosAreaTecnica.Columns[2].Width = 110;
        }

        private void preencheGridAreaTecnica()
        {
            grdDadosAreaTecnica.DataSource = AT.select();
            formataGridAreaTecnica();
        }

        private void preencheDadosControle()
        {
            AT.selectAT();
            txtCod_AT.Text = AT.GetCodAT().ToString();
            txtDescricao_AT.Text = AT.GetDescricaoAT();
            txtQtd_AT.Text = AT.GetQtdAT().ToString();
        }

        private void salvarAreaTecnica()
        {
            AT.SetCodAT(Convert.ToInt32(txtCod_AT.Text));
            AT.SetDescricaoAT(txtDescricao_AT.Text);
            AT.SetQtdAT(Convert.ToInt32(txtQtd_AT.Text));

            if (newAreaTec == true)
            {
                AT.inserir();
            }
            else
            {
                AT.update();
            }
            newAreaTec = false;
        }

        private void excluiAreaTecnica()
        {
            AT.delete();
        }

        private void CadastroAreaTecnica_Load(object sender, EventArgs e)
        {
            habilitaControlesAreaTecnica(false);
            gerenciaBotoesBarra(true);
            preencheGridAreaTecnica();
        }
        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaControlesAreaTecnica(true);
            limparControles();
            gerenciaBotoesBarra(false);
            newAreaTec = true;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            habilitaControlesAreaTecnica(true);
            gerenciaBotoesBarra(false);
            newAreaTec = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            habilitaControlesAreaTecnica(false);
            limparControles();
            gerenciaBotoesBarra(true);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            salvarAreaTecnica();
            habilitaControlesAreaTecnica(false);
            limparControles();
            gerenciaBotoesBarra(true);
            preencheGridAreaTecnica();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (AT.GetCodAT() != 0)
            {
                DialogResult retorno = MessageBox.Show("Deseja excluir a Área Técnica?", "Exclusão",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (retorno == DialogResult.Yes)
                {
                    excluiAreaTecnica();
                    limparControles();
                    preencheGridAreaTecnica();
                }
            }
            else
            {
                MessageBox.Show("Selecione uma Área Técnica para Excluir!!", "Aviso!!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void grdDadosAreaTecnica_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grdDadosAreaTecnica.CurrentRow != null)
            {
                AT.SetCodAT(Convert.ToInt32(grdDadosAreaTecnica.Rows[grdDadosAreaTecnica.CurrentRow.Index].Cells[0].Value.ToString()));
                preencheDadosControle();
                //preencheGridAreaTecnica();
            }
        }
        
    }
}
