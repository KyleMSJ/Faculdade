﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace EscolaTecnica
{
    public partial class CadastroProfessor : Form
    {
        csProfessor prof = new csProfessor();

        bool novoProf = false;
        private void habilitaControles(bool status)
        {
            txtNomeP.Enabled = status;
            txtCode_P.Enabled = status;
            txtBirthDate_P.Enabled = status;
            txtCursos_P.Enabled = status;
            txtSalario_P.Enabled = status;
        }

        private void limparControles()
        {
            txtNomeP.Text = "";
            txtBirthDate_P.Text = "";
            txtCode_P.Text = "";
            txtCursos_P.Text = "";
            txtSalario_P.Text = "";
        }

        private void gerenciaBotoesBarra(bool status)
        {
            btnNovo.Enabled = status;
            btnEditar.Enabled = status;
            btnExcluir.Enabled = status;
            btnSair.Enabled = status;
            btnSalvar.Enabled = !status;
            btnCancelar.Enabled = !status;
        }

        private void formataGrid()
        {
            grdDadosProfessor.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdDadosProfessor.Columns[0].HeaderText = "Código";
            grdDadosProfessor.Columns[1].HeaderText = "Nome";
            grdDadosProfessor.Columns[2].HeaderText = "Data de nascimento";
            grdDadosProfessor.Columns[3].HeaderText = "Cursos ministrados";
            grdDadosProfessor.Columns[4].HeaderText = "Salario";

            grdDadosProfessor.Columns[0].Width = 60;
            grdDadosProfessor.Columns[1].Width = 285;
            grdDadosProfessor.Columns[2].Width = 100;
            grdDadosProfessor.Columns[3].Width = 85;
            grdDadosProfessor.Columns[4].Width = 75;

        }

        private void preencheGrid()
        {
            grdDadosProfessor.DataSource = prof.Select();
            formataGrid();
        }
        private void excluiProfessor()
        {
            prof.delete();
        }

        private void salvarProfessor()
        {
            prof.setCodProfessor(Convert.ToInt32(txtCode_P.Text));
            prof.setDataNasc(Convert.ToDateTime(txtBirthDate_P.Text));
            prof.setNomeProfessor(txtNomeP.Text);
            prof.setQtdCursos(Convert.ToInt32(txtCursos_P.Text));
            prof.setSalarioProfessor(Convert.ToDouble(txtSalario_P.Text));

            if (novoProf == true)
            {
                prof.inserir();
            }
            else
            {
                prof.update();
            }
            novoProf = false;
        }
        private void preencheDadosControles()
        {
            prof.selectProfessor();

            txtNomeP.Text = prof.getNomeProfessor();
            txtSalario_P.Text = prof.getSalarioProfessor().ToString();
            txtCode_P.Text = prof.getCodProfessor().ToString();
            txtCursos_P.Text = prof.getQtdCursos().ToString();
            txtBirthDate_P.Text = prof.getDataNasc().ToString();
        }

        public CadastroProfessor()
        {
            InitializeComponent();
        }

        private void CadastroProfessor_Load(object sender, EventArgs e)
        {
            habilitaControles(false);
            gerenciaBotoesBarra(true);
            preencheGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            limparControles();
            gerenciaBotoesBarra(false);
            novoProf = true;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            gerenciaBotoesBarra(false);
            novoProf = false;
            txtCode_P.Enabled = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja cancelar o cadastro do professor?", "Aviso!!!",
               MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            salvarProfessor();
            habilitaControles(false);
            limparControles();
            gerenciaBotoesBarra(true);
            preencheGrid();
        }


        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (prof.getCodProfessor() != 0)
            {
                DialogResult retorno = MessageBox.Show("Deseja excluir os dados do professor selecionado?", "Exclusão",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (retorno == DialogResult.Yes)
                {
                    excluiProfessor();
                    limparControles();
                    preencheGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione o professor para excluir", "Aviso!!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void grdDados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grdDadosProfessor.CurrentRow != null)
            {
                prof.setCodProfessor(Convert.ToInt32(grdDadosProfessor.Rows[grdDadosProfessor.CurrentRow.Index].Cells[0].Value.ToString()));
                preencheDadosControles();
            }

        }
    }
}


