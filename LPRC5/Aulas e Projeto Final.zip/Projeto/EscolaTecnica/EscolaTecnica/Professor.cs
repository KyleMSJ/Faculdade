﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Data;
using System.Globalization;

namespace EscolaTecnica
{
    public class csProfessor
    { 
        private Int32 Cod;
        private string nome_prof;
        private DateTime data_nasc;
        public Int32 qtd_cursos;
        private double salario;

        private ConexaoPostgreSQL connectP = new ConexaoPostgreSQL();

        public void setCodProfessor(Int32 valor)
        {
            Cod = valor;
        }

        public Int32 getCodProfessor()
        {
            return Cod;
        }

        public void setNomeProfessor(string valor)
        {
            nome_prof = valor;
        }

        public string getNomeProfessor()
        {
            return nome_prof;
        }

        public void setDataNasc(DateTime valor)
        {
            data_nasc = valor;
        }

        public DateTime getDataNasc()
        {
            return data_nasc;
        }

        public void setQtdCursos(Int32 valor)
        {
            qtd_cursos = valor;
        }

        public Int32 getQtdCursos()
        {
            return qtd_cursos;
        }

        public void setSalarioProfessor(double valor)
        {
            salario = valor;
        }

        public double getSalarioProfessor()
        {
            return salario;
        }



        public void inserir()
        {
            string sql = "INSERT INTO tb.professor (id_prof, nome, d_nasc, ";
        sql += "qtd_cursos_ministrados, salario) VALUES (";
        sql += Cod.ToString() + ", ";
        sql += "'" + nome_prof + "', ";
        sql += "'" + data_nasc.ToString("yyyy-MM-dd") + "', ";
        sql += qtd_cursos.ToString() + ", ";
        sql += salario.ToString() + ")";
        connectP.executarSql(sql);
        }

        public void delete()
        { 
        string sql = "Delete from tb.professor WHERE id_prof = " + Cod.ToString() + ";";
        connectP.executarSql(sql);
        }

        public void update()
        {
        string sql = "UPDATE tb.professor SET ";
        sql += "nome = '" + nome_prof + "',";
        sql += "d_nasc = '" + data_nasc.ToString("yyyy-MM-dd") + "',";
        sql += "qtd_cursos_ministrados = " + qtd_cursos.ToString() + ", ";
        sql += "salario = " + salario.ToString();
        sql += " WHERE id_prof = " + Cod + ";";
        connectP.executarSql(sql);
        // "N", CultureInfo.CreateSpecificCulture("en-US") -> Permite a conversão da ',' para '.'
        }
        public DataTable Select()
        {
        NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
        DataTable tabela = new DataTable();
        string sql = "Select id_prof, nome, d_nasc, qtd_cursos_ministrados, salario " +
                "FROM tb.professor;";
        adapter = connectP.executaRetornaDados(sql);
        adapter.Fill(tabela);
        return tabela;
        }

        public void selectProfessor()
        {
        NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
        DataSet dataSet = new DataSet();
        string sql = "SELECT nome, d_nasc, qtd_cursos_ministrados, salario " +
                "FROM tb.professor WHERE id_prof = " + Cod + ";";
        adapter = connectP.executaRetornaDados(sql);
        adapter.Fill(dataSet);

        nome_prof = dataSet.Tables[0].Rows[0][0].ToString();
        data_nasc = Convert.ToDateTime(dataSet.Tables[0].Rows[0][1].ToString());
        qtd_cursos = Convert.ToInt32(dataSet.Tables[0].Rows[0][2].ToString());
        salario = Convert.ToDouble(dataSet.Tables[0].Rows[0][3].ToString());
        }
    }
}

