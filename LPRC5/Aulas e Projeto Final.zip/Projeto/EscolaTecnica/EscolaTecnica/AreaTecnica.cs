﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Data;


namespace EscolaTecnica
{
	public class csAreaTecnica
	{
		private Int32 codAT;
		private Int32 qtdAT;
		private string descricaoAT;

		private ConexaoPostgreSQL connectAT = new ConexaoPostgreSQL();
		public void SetCodAT(Int32 valor)
		{
			codAT = valor;
		}

		public Int32 GetCodAT()
		{
			return codAT;
		}

		public void SetQtdAT(Int32 valor)
		{
			qtdAT = valor;
		}
		public Int32 GetQtdAT()
		{
			return qtdAT;
		}
		public void SetDescricaoAT(string valor)
		{
			descricaoAT = valor;
		}
		public string GetDescricaoAT()
		{
			return descricaoAT;
		}

		public void inserir()
        {
			string sql = "INSERT INTO tb.areatec (id_area, descricao, qtd_cursos_possuidos)";
			sql += " VALUES (";
			sql += codAT.ToString() + ", ";
			sql += "'" + descricaoAT + "', ";
			sql += "" + qtdAT.ToString() + ")";
			connectAT.executarSql(sql);
		}
		public void delete()
        {
			string sql = "Delete from tb.areatec WHERE id_area = '" + codAT + "';";
			connectAT.executarSql(sql);
		}
		public void update()
        {
			string sql = "UPDATE tb.areatec SET ";
			sql += "descricao = '" + descricaoAT + "', ";
			sql += "qtd_cursos_possuidos = " + qtdAT.ToString() + "";
			sql += " WHERE id_area = " + codAT.ToString() + ";";
			connectAT.executarSql(sql);
		}
		public DataTable select()
        {
			NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
			DataTable tabela = new DataTable();
			string sql = "Select * from tb.areatec;";
			adapter = connectAT.executaRetornaDados(sql);
			adapter.Fill(tabela);
			return tabela;
		}

		public void selectAT()
        {
			NpgsqlDataAdapter adapter = new NpgsqlDataAdapter();
			DataSet dataSet = new DataSet();
			string sql = "SELECT descricao, qtd_cursos_possuidos FROM tb.areatec WHERE id_area = " + codAT + ";";
			adapter = connectAT.executaRetornaDados(sql);
			adapter.Fill(dataSet);

			descricaoAT = dataSet.Tables[0].Rows[0][0].ToString();
			qtdAT = Convert.ToInt32(dataSet.Tables[0].Rows[0][1].ToString()); 
		}
	}
}



