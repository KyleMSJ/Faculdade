﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolaTecnica
{
    public partial class CadastroCursos : Form
    {
        csCurso curso = new csCurso();

        bool newCurso = false;
        private void habilitaControles(bool status)
        {
            txtNroC.Enabled = status;
            txtNomeC.Enabled = status;
            txt_ProfessorC.Enabled = status;
            txtAreaTecnica_C.Enabled = status;
            txt_iniDateC.Enabled = status;
            txt_endDateC.Enabled = status;
        }

        private void limparControles()
        {
            txtNroC.Text = "";
            txtNomeC.Text = "";
            txt_ProfessorC.Text = "";
            txtAreaTecnica_C.Text = "";
            txt_iniDateC.Text = "";
            txt_endDateC.Text = "";
        }

        private void gerenciaBotoesBarra(bool status)
        {
            btnNovo.Enabled = status;
            btnEditar.Enabled = status;
            btnExcluir.Enabled = status;
            btnSair.Enabled = status;
            btnSalvar.Enabled = !status;
            btnCancelar.Enabled = !status;
        }

        private void formataGrid()
        {
            grdDadosCursos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            grdDadosCursos.Columns[0].HeaderText = "Número";
            grdDadosCursos.Columns[1].HeaderText = "Nome";
            grdDadosCursos.Columns[2].HeaderText = "Area Tecnica";

            grdDadosCursos.Columns[0].Width = 60;
            grdDadosCursos.Columns[1].Width = 220;
            grdDadosCursos.Columns[2].Width = 120;
        }

        private void preencheGrid()
        {
            grdDadosCursos.DataSource = curso.select();
            formataGrid();
        }

        private void excluiCurso()
        {
            curso.delete();
        }

        private void salvarCurso()
        {
            curso.setCursoNro(Convert.ToInt32(txtNroC.Text));
            curso.setCursoNome(txtNomeC.Text);
            curso.setProfResp(Convert.ToInt32(txt_ProfessorC.Text));
            curso.setATec_C(Convert.ToInt32(txtAreaTecnica_C.Text));
            curso.setDataIni(Convert.ToDateTime(txt_iniDateC.Text));
            curso.setDataEnd(Convert.ToDateTime(txt_endDateC.Text));


            if (newCurso == true) 
            {
                curso.inserir();
            }
            else
            {
                curso.update();
            }
            newCurso = false;
        }

        private void preencheDadosControles()
        {
            curso.selectCurso();

            txtNroC.Text = curso.getCursoNro().ToString();
            txtNomeC.Text = curso.getCursoNome();
            txt_ProfessorC.Text = curso.getProfResp().ToString();
            txtAreaTecnica_C.Text = curso.getATec_C().ToString();
            txt_iniDateC.Text = curso.getDataIni().ToString();
            txt_endDateC.Text = curso.getDataEnd().ToString();
        }

        public CadastroCursos()
        {
            InitializeComponent();
        }

        private void CadastroCursos_Load(object sender, EventArgs e)
        {
            habilitaControles(false);
            gerenciaBotoesBarra(true);
            preencheGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            limparControles();
            gerenciaBotoesBarra(false);
            newCurso = true;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            habilitaControles(true);
            gerenciaBotoesBarra(false);
            newCurso = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja cancelar o cadastro do Curso?", "Aviso!!!",
               MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (validaData() == true)
            {
                salvarCurso();
                habilitaControles(false);
                limparControles();
                gerenciaBotoesBarra(true);
                preencheGrid();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (curso.getCursoNro() != 0)
            {
                DialogResult retorno = MessageBox.Show("Deseja excluir os dados do curso selecionado?", "Exclusão",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (retorno == DialogResult.Yes)
                {
                    excluiCurso();
                    limparControles();
                    preencheGrid();
                }
            }
            else
            {
                MessageBox.Show("Selecione o curso para excluir", "Aviso!!!", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private bool validaData()
        {
            if (Convert.ToDateTime(txt_iniDateC.Text) < DateTime.Now)
            {
                MessageBox.Show("Informe uma data válida!", "Aviso!!",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                txt_iniDateC.Focus();
                return false;
            }
            return true;
        }

        private void grdDadosCursos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (grdDadosCursos.CurrentRow != null)
            {
                curso.setCursoNro(Convert.ToInt32(grdDadosCursos.Rows[grdDadosCursos.CurrentRow.Index].Cells[0].Value.ToString()));
                preencheDadosControles();
                //preencheGrid();
            }
        }
    }
}


