﻿
namespace EscolaTecnica
{
    partial class CadastroCursos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroCursos));
            this.lblAreaTecnica_C = new System.Windows.Forms.Label();
            this.lbl_ProfessorC = new System.Windows.Forms.Label();
            this.txt_ProfessorC = new System.Windows.Forms.TextBox();
            this.txtAreaTecnica_C = new System.Windows.Forms.TextBox();
            this.txt_endDateC = new System.Windows.Forms.MaskedTextBox();
            this.lbl_endDateC = new System.Windows.Forms.Label();
            this.txt_iniDateC = new System.Windows.Forms.MaskedTextBox();
            this.lbl_iniDateC = new System.Windows.Forms.Label();
            this.lblNroC = new System.Windows.Forms.Label();
            this.txtNroC = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnEditar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.lblNomeC = new System.Windows.Forms.Label();
            this.grdDadosCursos = new System.Windows.Forms.DataGridView();
            this.txtNomeC = new System.Windows.Forms.TextBox();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosCursos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAreaTecnica_C
            // 
            this.lblAreaTecnica_C.AutoSize = true;
            this.lblAreaTecnica_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaTecnica_C.Location = new System.Drawing.Point(356, 208);
            this.lblAreaTecnica_C.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAreaTecnica_C.Name = "lblAreaTecnica_C";
            this.lblAreaTecnica_C.Size = new System.Drawing.Size(102, 20);
            this.lblAreaTecnica_C.TabIndex = 69;
            this.lblAreaTecnica_C.Text = "Área Técnica";
            // 
            // lbl_ProfessorC
            // 
            this.lbl_ProfessorC.AutoSize = true;
            this.lbl_ProfessorC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProfessorC.Location = new System.Drawing.Point(356, 147);
            this.lbl_ProfessorC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ProfessorC.Name = "lbl_ProfessorC";
            this.lbl_ProfessorC.Size = new System.Drawing.Size(173, 20);
            this.lbl_ProfessorC.TabIndex = 68;
            this.lbl_ProfessorC.Text = "Professor Responsável";
            // 
            // txt_ProfessorC
            // 
            this.txt_ProfessorC.Location = new System.Drawing.Point(360, 172);
            this.txt_ProfessorC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_ProfessorC.Name = "txt_ProfessorC";
            this.txt_ProfessorC.Size = new System.Drawing.Size(169, 20);
            this.txt_ProfessorC.TabIndex = 67;
            // 
            // txtAreaTecnica_C
            // 
            this.txtAreaTecnica_C.Location = new System.Drawing.Point(360, 233);
            this.txtAreaTecnica_C.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAreaTecnica_C.Name = "txtAreaTecnica_C";
            this.txtAreaTecnica_C.Size = new System.Drawing.Size(98, 20);
            this.txtAreaTecnica_C.TabIndex = 65;
            // 
            // txt_endDateC
            // 
            this.txt_endDateC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_endDateC.Location = new System.Drawing.Point(652, 421);
            this.txt_endDateC.Mask = "00/00/0000";
            this.txt_endDateC.Name = "txt_endDateC";
            this.txt_endDateC.Size = new System.Drawing.Size(67, 22);
            this.txt_endDateC.TabIndex = 64;
            this.txt_endDateC.ValidatingType = typeof(System.DateTime);
            // 
            // lbl_endDateC
            // 
            this.lbl_endDateC.AutoSize = true;
            this.lbl_endDateC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_endDateC.Location = new System.Drawing.Point(470, 423);
            this.lbl_endDateC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_endDateC.Name = "lbl_endDateC";
            this.lbl_endDateC.Size = new System.Drawing.Size(175, 20);
            this.lbl_endDateC.TabIndex = 63;
            this.lbl_endDateC.Text = "Data de Encerramento:";
            // 
            // txt_iniDateC
            // 
            this.txt_iniDateC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_iniDateC.Location = new System.Drawing.Point(652, 388);
            this.txt_iniDateC.Mask = "00/00/0000";
            this.txt_iniDateC.Name = "txt_iniDateC";
            this.txt_iniDateC.Size = new System.Drawing.Size(67, 22);
            this.txt_iniDateC.TabIndex = 62;
            this.txt_iniDateC.ValidatingType = typeof(System.DateTime);
            // 
            // lbl_iniDateC
            // 
            this.lbl_iniDateC.AutoSize = true;
            this.lbl_iniDateC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_iniDateC.Location = new System.Drawing.Point(506, 390);
            this.lbl_iniDateC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_iniDateC.Name = "lbl_iniDateC";
            this.lbl_iniDateC.Size = new System.Drawing.Size(111, 20);
            this.lbl_iniDateC.TabIndex = 61;
            this.lbl_iniDateC.Text = "Data de Início:";
            // 
            // lblNroC
            // 
            this.lblNroC.AutoSize = true;
            this.lblNroC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNroC.Location = new System.Drawing.Point(356, 69);
            this.lblNroC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNroC.Name = "lblNroC";
            this.lblNroC.Size = new System.Drawing.Size(65, 20);
            this.lblNroC.TabIndex = 60;
            this.lblNroC.Text = "Número";
            // 
            // txtNroC
            // 
            this.txtNroC.Location = new System.Drawing.Point(360, 94);
            this.txtNroC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNroC.Name = "txtNroC";
            this.txtNroC.Size = new System.Drawing.Size(77, 20);
            this.txtNroC.TabIndex = 59;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNovo,
            this.btnEditar,
            this.btnCancelar,
            this.btnSalvar,
            this.btnExcluir,
            this.btnSair});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.MaximumSize = new System.Drawing.Size(1200, 154);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip1.Size = new System.Drawing.Size(731, 57);
            this.toolStrip1.TabIndex = 58;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnNovo
            // 
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(54, 54);
            this.btnNovo.Text = "toolStripButton1";
            this.btnNovo.ToolTipText = "Cadastra novo funcionário";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnEditar.Image = ((System.Drawing.Image)(resources.GetObject("btnEditar.Image")));
            this.btnEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(54, 54);
            this.btnEditar.Text = "toolStripButton2";
            this.btnEditar.ToolTipText = "Edita dados do funcionário";
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(54, 54);
            this.btnCancelar.Text = "toolStripButton3";
            this.btnCancelar.ToolTipText = "Cancelar cadastro";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(54, 54);
            this.btnSalvar.Text = "toolStripButton4";
            this.btnSalvar.ToolTipText = "Salvar dados do funcionário";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(54, 54);
            this.btnExcluir.Text = "toolStripButton5";
            this.btnExcluir.ToolTipText = "Excluir dados do funcionário";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(54, 54);
            this.btnSair.Text = "toolStripButton6";
            this.btnSair.ToolTipText = "Sair do cadastro";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblNomeC
            // 
            this.lblNomeC.AutoSize = true;
            this.lblNomeC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeC.Location = new System.Drawing.Point(463, 69);
            this.lblNomeC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeC.Name = "lblNomeC";
            this.lblNomeC.Size = new System.Drawing.Size(51, 20);
            this.lblNomeC.TabIndex = 57;
            this.lblNomeC.Text = "Nome";
            // 
            // grdDadosCursos
            // 
            this.grdDadosCursos.AllowUserToAddRows = false;
            this.grdDadosCursos.AllowUserToDeleteRows = false;
            this.grdDadosCursos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdDadosCursos.Location = new System.Drawing.Point(13, 72);
            this.grdDadosCursos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.grdDadosCursos.Name = "grdDadosCursos";
            this.grdDadosCursos.ReadOnly = true;
            this.grdDadosCursos.Size = new System.Drawing.Size(335, 371);
            this.grdDadosCursos.TabIndex = 56;
            this.grdDadosCursos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdDadosCursos_CellClick);
            // 
            // txtNomeC
            // 
            this.txtNomeC.Location = new System.Drawing.Point(467, 94);
            this.txtNomeC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNomeC.Name = "txtNomeC";
            this.txtNomeC.Size = new System.Drawing.Size(227, 20);
            this.txtNomeC.TabIndex = 55;
            // 
            // CadastroCursos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 468);
            this.Controls.Add(this.lblAreaTecnica_C);
            this.Controls.Add(this.lbl_ProfessorC);
            this.Controls.Add(this.txt_ProfessorC);
            this.Controls.Add(this.txtAreaTecnica_C);
            this.Controls.Add(this.txt_endDateC);
            this.Controls.Add(this.lbl_endDateC);
            this.Controls.Add(this.txt_iniDateC);
            this.Controls.Add(this.lbl_iniDateC);
            this.Controls.Add(this.lblNroC);
            this.Controls.Add(this.txtNroC);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lblNomeC);
            this.Controls.Add(this.grdDadosCursos);
            this.Controls.Add(this.txtNomeC);
            this.Name = "CadastroCursos";
            this.Text = "Cadastro de Cursos";
            this.Load += new System.EventHandler(this.CadastroCursos_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdDadosCursos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAreaTecnica_C;
        private System.Windows.Forms.Label lbl_ProfessorC;
        private System.Windows.Forms.TextBox txt_ProfessorC;
        private System.Windows.Forms.TextBox txtAreaTecnica_C;
        private System.Windows.Forms.MaskedTextBox txt_endDateC;
        private System.Windows.Forms.Label lbl_endDateC;
        private System.Windows.Forms.MaskedTextBox txt_iniDateC;
        private System.Windows.Forms.Label lbl_iniDateC;
        private System.Windows.Forms.Label lblNroC;
        private System.Windows.Forms.TextBox txtNroC;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnEditar;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.Label lblNomeC;
        private System.Windows.Forms.DataGridView grdDadosCursos;
        private System.Windows.Forms.TextBox txtNomeC;
    }
}