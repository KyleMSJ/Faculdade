package ModificadoresAcesso1;

public class Fusca extends Carro {

	public Fusca() {
		this.cor = "Branco";
		this.marca = "WM";
		this.ligar();
		this.toString();
	}
}
