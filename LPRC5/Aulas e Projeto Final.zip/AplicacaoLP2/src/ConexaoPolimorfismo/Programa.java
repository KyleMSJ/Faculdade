package ConexaoPolimorfismo;

public class Programa implements IEntidade{
	
	IEntidade iEnt;
    public Programa(IEntidade iEnt){
        this.iEnt = iEnt;        
    }
    
    
    public void cadastrar(){
        iEnt.cadastrar();
    }
    
        
    public void atualizar(){
        iEnt.atualizar();
    }
    
}

