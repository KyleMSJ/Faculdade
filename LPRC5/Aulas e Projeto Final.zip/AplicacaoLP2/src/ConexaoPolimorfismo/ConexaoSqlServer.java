package ConexaoPolimorfismo;

public class ConexaoSqlServer implements IConexao{
	@Override
    public void conectar() {
        System.out.println("Conectou via SQLServer");
    }

    @Override
    public void desconectar() {
        System.out.println("Desconectou via SQLServer");
    }
    
}
