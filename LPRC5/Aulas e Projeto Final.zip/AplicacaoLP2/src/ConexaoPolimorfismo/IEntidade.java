package ConexaoPolimorfismo;

public interface IEntidade {

	public void cadastrar();
	public void atualizar();
}
