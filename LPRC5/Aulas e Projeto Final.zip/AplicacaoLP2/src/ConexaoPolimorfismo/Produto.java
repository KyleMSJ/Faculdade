package ConexaoPolimorfismo;

public class Produto implements IEntidade{
	  IConexao conn;
	    public Produto(IConexao conn){
	        this.conn = conn;
	    }
	   /* 
	    public void cadastrar(){
	        conn.conectar();
	        //Regras, SQL
	        conn.desconectar();
	        
	    }*/
	    
	    @Override
	    public void cadastrar() {
	        conn.conectar();        
	        System.out.println("Cadastrou produto");
	        conn.desconectar();
	    }

	    @Override
	    public void atualizar() {
	       conn.conectar();  
	       System.out.println("Atualizou produto");
	       conn.desconectar();
	    }    
	    
	    
	    
	    

}
