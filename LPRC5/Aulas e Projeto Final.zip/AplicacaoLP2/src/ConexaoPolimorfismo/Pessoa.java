package ConexaoPolimorfismo;

public class Pessoa implements IEntidade{

	IConexao conn;
	public Pessoa(IConexao conn) {
		this.conn = conn;
	}
	 @Override
	    public void cadastrar() {
	        conn.conectar();        
	        System.out.println("Cadastrou pessoa");
	        conn.desconectar();        
	    }

    @Override
	    public void atualizar() {
	        conn.conectar();        
	        System.out.println("atualizou pessoa");
	        conn.desconectar();       
	    }
	    
}
