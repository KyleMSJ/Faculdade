package ConexaoPolimorfismo;

public class ConexaoMySQL implements IConexao{
	@Override
    public void conectar() {
        System.out.println("Conectou via MYServer");
    }

    @Override
    public void desconectar() {
        System.out.println("Desconectou via MyServer");
    }
}

