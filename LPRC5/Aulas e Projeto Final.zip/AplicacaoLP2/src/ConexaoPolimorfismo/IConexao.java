package ConexaoPolimorfismo;

public interface IConexao {
	public void conectar();
	public void desconectar();
}
