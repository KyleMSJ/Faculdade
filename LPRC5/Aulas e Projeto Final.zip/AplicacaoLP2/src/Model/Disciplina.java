/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Aluno
 */
public class Disciplina {
    
    private int cod;
    private int codAluno;

    public int getCodAluno() {
        return codAluno;
    }

    public void setCodAluno(int codAluno) {
        this.codAluno = codAluno;
    }
    private String nome;
    private float nota1;
    private float nota2;
    private float media;
    private String situacao;

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getNota1() {
        return nota1;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }

    public float getMedia() {
        return media;
    }

    public void setMedia(float media) {
        this.media = media;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }    
    
    public List<Disciplina>  calculaMedia(List<Disciplina> listaDisciplina){
        List<Disciplina> listDisciplina = new ArrayList<Disciplina>();
        for(Disciplina objDisc: listaDisciplina){
            objDisc.setMedia((objDisc.getNota1()+objDisc.getNota2())/2);
            objDisc.setSituacao(verificarSituacao(objDisc.getMedia())); 
            listDisciplina.add(objDisc);
        }               
     return listDisciplina;
    }  
    
    public String verificarSituacao(float media){
        System.out.println("\n media " + media);
        String s = "";
        if (media >= 7){
           s = "Aprovado" ;
        }else if (media >=4){
            s = "Exame" ;
        }else{
            s = "Reprovado" ;
        }       
        return s;
    }
    
    
}
