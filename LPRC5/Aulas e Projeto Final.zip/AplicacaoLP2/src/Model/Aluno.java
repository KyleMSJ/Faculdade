/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Aluno
 */
public class Aluno {
    
    private int cod;
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
        }
    
    public int getCod(){        
        return cod;
    }
    
    public void setCod(int cod){
        this.cod = cod;
    }
    
    
    
}
