/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Thread;

/**
 *
 * @author Aluno
 */
public class ThreadA {
    public static void main(String[] args) throws InterruptedException 
            ThreadB b = new ThreadB();
            b.start();
            synchronized(b){ // espera ThreadB 
                try{
                    System.out.println("\n Aguardando o b completar");
                    b.wait();
                } catch (InterruptedException ex) {
                    System.out.println("\n Erro! ");
                }
            } // processar
            System.out.println("\n Total é: " + b.total);
}
