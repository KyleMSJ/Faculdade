/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Thread;

/**
 *
 * @author Aluno
 */
public class ProgramaThread implements Runnable {
  
    private int iD;

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }
    
    @Override
    public void run()
    {
        for (int x = 0; x < 200; x++){
        try {
            Thread.sleep(500);
        }
        catch (InterruptedException ex){
            System.out.println(ProgramaThread.class.getName());
        }
            System.out.println("\n Linha: " + x + " Instância: ");
                    }
    }
}
