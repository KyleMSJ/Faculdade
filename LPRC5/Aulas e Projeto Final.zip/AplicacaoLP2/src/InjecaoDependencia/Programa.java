/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InjecaoDependencia;

/**
 *
 * @author Aluno
 */
public class Programa {
    IEntidade iEnt;
    public Programa(IEntidade iEnt){
        this.iEnt = iEnt;        
    }
    
    public void cadastrar(){
        iEnt.cadastrar();
    }
        
    public void atualizar(){
        iEnt.atualizar();
    }
    
}

