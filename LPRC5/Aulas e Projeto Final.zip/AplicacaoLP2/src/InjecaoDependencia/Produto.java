/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InjecaoDependencia;

/**
 *
 * @author Aluno
 */
public class Produto implements IEntidade{
        
    IConexao conn;
    public Produto(IConexao conn){
        this.conn = conn;
    }
    @Override
    public void cadastrar(){
        conn.conectar();
        System.out.println("Cadastrou Produto");
        conn.desconectar();
    }
    
    @Override
    public void deletar(){
        conn.conectar();
        System.out.println("Deletou Produto");
        conn.desconectar();
    }
    
    @Override
    public void atualizar(){
        conn.conectar();
        System.out.println("Atualizou Produto");
        conn.desconectar();
    }
    
    @Override
    public void selecionar(){
        conn.conectar();
        System.out.println("Selecionou Produto");
        conn.desconectar();
    }
}
