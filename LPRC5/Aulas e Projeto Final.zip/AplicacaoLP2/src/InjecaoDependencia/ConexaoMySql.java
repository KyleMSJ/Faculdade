/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InjecaoDependencia;

/**
 *
 * @author Aluno
 */
public class ConexaoMySql implements IConexao{
    
    @Override
    public void conectar() {
        System.out.println("Conectou via MySqlServer");
    }

    @Override
    public void desconectar() {
        System.out.println("Desconectou via MySqlServer");
    }
}

