/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InjecaoDependencia;

/**
 *
 * @author Aluno
 */
public class Pessoa implements IEntidade{
    
   IConexao conn;
    public Pessoa (IConexao conn){
        this.conn = conn;
    }
    @Override
    public void cadastrar(){
        conn.conectar();
        System.out.println("Cadastrou Pessoa");
        conn.desconectar();
    }
    
    @Override
    public void deletar(){
        conn.conectar();
        System.out.println("Deletou Pessoa");
        conn.desconectar();
    }
    
    @Override
    public void atualizar(){
        conn.conectar();
        System.out.println("Atualizou Pessoa");
        conn.desconectar();
    }
    
    @Override
    public void selecionar(){
        conn.conectar();
        System.out.println("Selecionou Pessoa");
        conn.desconectar();
    }
}
