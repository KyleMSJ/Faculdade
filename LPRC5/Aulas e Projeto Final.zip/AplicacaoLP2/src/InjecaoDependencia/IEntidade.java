/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InjecaoDependencia;

/**
 *
 * @author Aluno
 */
public interface IEntidade {
    public void cadastrar();
    public void deletar();
    public void atualizar();
    public void selecionar();
    /*public Entidade(){
	
        IConexao conn; // Instanciando a interface
	public Entidade(IConexao conn) { // Injeção
            this.conn = conn;
	}
	public void cadastrar() {
            conn.conectar(); // polimorfismo: mesmo método com comportamentos distintos (MySQL x SQL Server)
            // processamento
            conn.desconectar();
	}
	public void atualizar() {
            conn.conectar(); 
            // processamento
            conn.desconectar();
}*/
}
