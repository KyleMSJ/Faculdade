/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstratas;

/**
 *
 * @author Aluno
 */
public class FuncionarioAb extends PessoaAb {
    
    @Override
    public double calcular(double v1, double v2){
        
        return 5;
    }
    
    
        public static String armazenarNome(String nome){
            return nome;
        }
    
    
}
