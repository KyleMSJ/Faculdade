/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstratas;

/**
 *
 * @author Aluno
 */
public abstract class PessoaAb {
    
    int cod;
    String nome;
    
    public void cadastrar(){        
        System.out.print("teste");        
              
    }
    
    public abstract double calcular(double v1, double v2); 
        
    

    
}
