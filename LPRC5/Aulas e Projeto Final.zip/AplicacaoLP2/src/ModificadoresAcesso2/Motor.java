package ModificadoresAcesso2;

public class Motor {

	public int potencia;
	
	public void darPartida() {
		System.out.print("Deu a partida");
	}
}
