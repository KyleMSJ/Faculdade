package ModificadoresAcesso2;

import ModificadoresAcesso1.Carro;

public class BrasiliaAmarela extends Carro {
	public BrasiliaAmarela() {
        this.cor = "Amarelo";
        this.marca = "VW";
        this.ligar();
        this.toString();
        this.motor.darPartida();
        
    }
}
