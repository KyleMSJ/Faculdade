/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LP2;

import Thread.*;
/**
 *
 * @author Aluno
 */
public class LP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        
        String parar = "0";
        List<Disciplina> listDisciplina = new ArrayList<Disciplina>();
        List<Aluno> listAluno = new ArrayList<Aluno>();

        do{
            
            Aluno objAluno = new Aluno();
            Disciplina objDisciplina = new Disciplina();
            objAluno.setNome(JOptionPane.showInputDialog("Digite seu nome: "));
            objAluno.setCod(Integer.parseInt(JOptionPane.showInputDialog("Digite seu código: ")));            
            objDisciplina.setNota1(Float.parseFloat(JOptionPane.showInputDialog("Digite sua nota1: ")));
            objDisciplina.setNota2(Float.parseFloat(JOptionPane.showInputDialog("Digite sua nota2: ")));            
            parar = JOptionPane.showInputDialog("Parar (2) Continuar (1) ");
            objDisciplina.setCodAluno(objAluno.getCod()); 
            
            listDisciplina.add(objDisciplina);
            listAluno.add(objAluno);
            
        }while(parar.equals("1"));
        
        Disciplina objDisciplina = new Disciplina();        
        listDisciplina = objDisciplina.calculaMedia(listDisciplina);
        
        for(Disciplina objD: listDisciplina){
            System.out.println(" ----- \n");
            System.out.println(" Nome do aluno " + objD.getNome());
            System.out.println(" código do luno " + objD.getCodAluno());
            System.out.println(" Situação do aluno " + objD.getSituacao());
            System.out.println(" Média aluno " + objD.getMedia()); 
            System.out.println(" ----- \n");
        }
*/
        
        /*
        Estudante objE = new Estudante();
        String n = objE.getGraduacao();
        n = objE.getNome();
        
        AlunoEspecial objAE = new AlunoEspecial();
        n = objAE.getNome();*/
        
      //  Entidade e = new Entidade(new ConexaoMySql());
      // e.cadastrar();
       
      /*Programa p = new Programa(new Pessoa(new ConexaoMySql())); 
      p.cadastrar();
      p.atualizar(); */
      
      // Usuário tipos genéricos
      /*String param = "test";
      ExemploUsoComGenerico<String> objEx = new ExemploUsoComGenerico<String>();
      objEx.configuraValor(param);
      
      Integer param2 = 2;
      ExemploUsoComGenerico<Integer> objEx2 = new ExemploUsoComGenerico<Integer>();
      objEx2.configuraValor(param2);
      

      Servico objS = new Servico();
      objS.setId(10);
      objS.setNome("IFSP");
      ExemploUsoComGenerico<Servico> objEx3 = new ExemploUsoComGenerico<Servico>();
      objEx3.configuraValor(objS);*/

      
    }
    
}
