/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HerancaMultipla;

/**
 *
 * @author Aluno
 */
public class Funcionario extends Pessoa {
    
    int cod;
    float salario;
    float horasSemanais;
    int carreira;

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getHorasSemanais() {
        return horasSemanais;
    }

    public void setHorasSemanais(float horasSemanais) {
        this.horasSemanais = horasSemanais;
    }

    public int getCarreira() {
        return carreira;
    }

    public void setCarreira(int carreira) {
        this.carreira = carreira;
    }
    
    
    
    
}
