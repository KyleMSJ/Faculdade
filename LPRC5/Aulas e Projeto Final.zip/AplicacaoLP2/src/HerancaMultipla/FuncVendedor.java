/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HerancaMultipla;

import HerancaMultipla.Funcionario;
import HerancaMultipla.IFuncionario;
import HerancaMultipla.IVendedor;
import HerancaMultipla.Vendedor;

/**
 *
 * @author Aluno
 */
public class FuncVendedor implements IVendedor, IFuncionario{
    
    @Override
    public Vendedor comissao(Vendedor v) {
        if(v.getCarreira()==1)        {
            v.setComissao(v.getVendas()* Float.parseFloat("0.1"));
        }else{
            v.setComissao(v.getVendas()* Float.parseFloat("0.2"));
        }
        return v;
    }

    @Override
    public Funcionario salario(Funcionario f) {
        if (f.getCarreira() == 1){
           f.setSalario((f.getHorasSemanais()*20)*4);           
        }else{
            f.setSalario((f.getHorasSemanais()*30)*4);           
        }
        return f; 
    }




    
}










