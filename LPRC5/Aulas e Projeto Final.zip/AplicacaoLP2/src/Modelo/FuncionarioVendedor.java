/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Interfaces.IFuncionario;
import Interfaces.IVendedor;

/**
 *
 * @author aluno
 */
public class FuncionarioVendedor implements IFuncionario, IVendedor {

    @Override
    public Funcionario calcularSalario(Funcionario f) {
        
        if (f.getTempoServico() > 10){
            f.setSalario(1000);
        }else{
            f.setSalario(500);
            
        }
        return f;
        
        
    }

    @Override
    public Vendedor calcularComissao(Vendedor v) {
        v.setComissao(300);
        return v;
    }


    
    
    
    
    
    
}
