/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author aluno
 */
public class Vendedor extends Pessoa {
    int cod;
    float comissao;
    String regiaoTrabalho;

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public float getComissao() {
        return comissao;
    }

    public void setComissao(float comissao) {
        this.comissao = comissao;
    }

    public String getRegiaoTrabalho() {
        return regiaoTrabalho;
    }

    public void setRegiaoTrabalho(String regiaoTrabalho) {
        this.regiaoTrabalho = regiaoTrabalho;
    }
    
    
    
    
}
