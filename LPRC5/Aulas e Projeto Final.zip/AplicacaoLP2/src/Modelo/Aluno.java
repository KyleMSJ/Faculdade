/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class Aluno {
    
    private int cod;
    private String nome;
    private String email;
    private String cpf;    
    
    public Aluno(){     
        System.out.println(" executando o construtor");
    }    
    
    public Aluno(String nome){
        this.nome = nome;        
    }
    
    public Aluno(int cod, String nome, String email, String cpf){
        this.cod = cod;
        this.nome = nome;        
        this.email = email;
        this.cpf = cpf;
    }     
    
    public void setNome(String nome){
        this.nome = nome;        
    }
    
    public String getNome(){
        return nome;
    }    

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    } //Assinatura dos métodos

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
    
    public int cadastrar(int cod, String nome){ //modificador de acesso | retorno | nome | parâmetros 
        int resultado = 0;
        
        
        return resultado;
    }
    
    
   public List<Aluno> selecionar(){ //modificador de acesso | retorno | nome | parâmetros 
        List<Aluno> listaAlunos = new ArrayList<>();
        Aluno objAluno = new Aluno();
        listaAlunos.add(objAluno);
        
        
        return listaAlunos;
    }   
   
   public Aluno recuperarDadosAluno(List<Aluno> listaAluno, int cod){
       Aluno obj = new Aluno();
       for (Aluno objAluno: listaAluno){
           if(objAluno.getCod()==cod){
               obj = objAluno;
               break;
           }
       }       
           return obj;
       }
   
       
       
   
   
   
   
  
    
    
    
    
}
