/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author aluno
 */
public class Estudante extends Pessoa{
    
    String matricula;
    String curso;
    String dataMatricula;    

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getDataMatricula() {
        return dataMatricula;
    }

    public void setDataMatricula(String dataMatricula) {
        this.dataMatricula = dataMatricula;
    }
    
    
    
    public String cadastrar(Estudante obj){
        String resultado;
        
        try{
        String dados;
        dados = obj.getNome();
        dados += obj.getEmail();
        dados = obj.getCurso();
        }catch(Exception ex){
            resultado = ex.getMessage() + ex.getStackTrace();
        }
        resultado = "Dados inseridos com sucesso";
        return resultado;       
    }

    
    
}
