package DAO;

import POJO.Produtos;

/**
 *
 * @author aluno
 */
public class produtosDAO {
    
    
    public void cadastrar(Produtos p){
        
        
    }
    
    
    
}

