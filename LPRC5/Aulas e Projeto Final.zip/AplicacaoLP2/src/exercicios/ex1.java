/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicios;
import javax.swing.JOptionPane; // caixas de diálogo
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Aluno
 */
public class ex1 { // Avaliação
	/*
	 * Um estabelecimento comercial possui margem de lucro de acordo com o valor do
	 * produto.
	 * 
	 * Faça um programa que leia o valor de custo do um produto e mostre na tela o
	 * valor do lucro da loja e qual o valor do produto com o lucro
	 */
	
	public static void main(String[] args) {
            
        List<Vendedor> ListVendedor = new ArrayList<Vendedor>();    
            
	Vendedor v = new Vendedor();	
	float valor = 0;
        double nValor = 0;
        String opt;
        int cont = 0;
        do {
        v.setCod(Integer.parseInt(JOptionPane.showInputDialog("Digite seu código: ")));
        v.setNome(JOptionPane.showInputDialog("Digite seu nome: "));
        v.setVenda(Float.parseFloat(JOptionPane.showInputDialog("Digite o valor vendido: ")));
        
        valor = v.getVenda();
        if(valor <= 1000.00) {
            v.setComissao(1.10);
            v.setSalario(1200*v.getComissao());   
        }
        else if (valor > 1000.00 && valor < 5000.00){
            v.setComissao(1.15);
            v.setSalario(1200*v.getComissao());
        }
        else {
            v.setComissao(1.25);
            v.setSalario(1200*v.getComissao());
        }
        ListVendedor.add(cont, v);
        cont++;
        opt = JOptionPane.showInputDialog("Deseja continuar? (s/n)");
        } while ("s".equals(opt));
        
        for (Vendedor objV : ListVendedor){
          System.out.print("\n------------------\n");
          System.out.print("Código do Vendedor:  " + objV.getCod() + "\n");             
          System.out.print("Nome do Vendedor:  " + objV.getNome() + "\n");
          System.out.print("Valor da comissão:  " + objV.getComissao() + "\n");
          System.out.print("Valor do salário:  " + objV.getSalario() + "\n");
          
          System.out.print("\n------------------\n"); 
        }
                 
	}
}

