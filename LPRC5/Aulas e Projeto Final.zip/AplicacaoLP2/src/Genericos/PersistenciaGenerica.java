/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Genericos;

/**
 *
 * @author Aluno
 */
public class PersistenciaGenerica <T> {
    
    private T data;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
    
    public PersistenciaGenerica(T data){
        this.data = data;
    }
    
    public void cadastrar(){
        T valor = (T)data;
        System.out.print("\n Cadastro feito com sucesso!");
        System.out.print(valor);
    }
    
    public T cadastrar2(){
        T valor = (T)data;
        return valor;
    }
}
