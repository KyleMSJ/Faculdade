/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Genericos;

/**
 *
 * @author Aluno
 */
public class ExemploUsoComGenerico <T>{
    
    public void configuraValor(T valor){
        
        if(valor instanceof String){
            valor = (T)(String) "É uma string";
        }
        else if(valor instanceof Integer){
            valor = (T)(Integer) 20;
        }
        else if(valor instanceof Double){
            valor = (T)(Double) 5.9;
        }
        else if(valor instanceof Servico){
            valor = (T)(Servico) valor;
        }
        System.out.println(valor);
    }
}
