/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Genericos;

/**
 *
 * @author Aluno
 * @param <T>
 */
public class Sample <T> {
    
    private T data;
    
    public void setData(T newData){
        data = newData;
    }
    
    public T getData()
    {
        return data;
    }
}
